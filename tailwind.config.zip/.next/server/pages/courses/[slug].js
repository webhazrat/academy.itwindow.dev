"use strict";
(() => {
var exports = {};
exports.id = 1355;
exports.ids = [1355];
exports.modules = {

/***/ 7066:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ SocialShare)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "next-share"
const external_next_share_namespaceObject = require("next-share");
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/SocialShare.jsx



function SocialShare({ url , title , description , hastag  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "h-5 flex gap-3",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(external_next_share_namespaceObject.FacebookShareButton, {
                url: url,
                quote: title,
                hashtag: hastag,
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/socials/facebook.svg",
                    width: 16,
                    height: 16,
                    alt: "facebook"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_next_share_namespaceObject.TwitterShareButton, {
                url: url,
                title: title,
                hashtag: hastag,
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/socials/twitter.svg",
                    width: 16,
                    height: 16,
                    alt: "twitter"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_next_share_namespaceObject.LinkedinShareButton, {
                url: url,
                title: title,
                summary: description,
                hashtag: hastag,
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/socials/linkedin.svg",
                    width: 16,
                    height: 16,
                    alt: "linkedin"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_next_share_namespaceObject.WhatsappShareButton, {
                url: url,
                title: title,
                separator: ":: ",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/socials/whatsapp.svg",
                    width: 16,
                    height: 16,
                    alt: "whatsapp"
                })
            })
        ]
    });
}


/***/ }),

/***/ 6494:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ SingleCourse),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _src_components_Accordion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8645);
/* harmony import */ var _src_components_FeebackItem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7061);
/* harmony import */ var _src_components_Layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(461);
/* harmony import */ var _src_components_ListItem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2031);
/* harmony import */ var _src_components_ui_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1276);
/* harmony import */ var _src_lib_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(873);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2423);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lucide_react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5941);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6641);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _src_components_SocialShare__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7066);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_components_Accordion__WEBPACK_IMPORTED_MODULE_1__, _src_components_Layout__WEBPACK_IMPORTED_MODULE_3__, _src_components_ui_button__WEBPACK_IMPORTED_MODULE_5__, _src_lib_utils__WEBPACK_IMPORTED_MODULE_6__, swr__WEBPACK_IMPORTED_MODULE_10__]);
([_src_components_Accordion__WEBPACK_IMPORTED_MODULE_1__, _src_components_Layout__WEBPACK_IMPORTED_MODULE_3__, _src_components_ui_button__WEBPACK_IMPORTED_MODULE_5__, _src_lib_utils__WEBPACK_IMPORTED_MODULE_6__, swr__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













function SingleCourse({ courseData  }) {
    const course = courseData.data;
    const { data: feedbacks , isLoading  } = (0,swr__WEBPACK_IMPORTED_MODULE_10__["default"])(`/api/feedbacks/course?courseId=${course._id}`, _src_lib_utils__WEBPACK_IMPORTED_MODULE_6__/* .fetcher */ ._i);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_11__.NextSeo, {
                title: course.title,
                description: course.description,
                canonical: `${_src_lib_utils__WEBPACK_IMPORTED_MODULE_6__/* .APP_URL */ .FX}/courses/${course.slug}`,
                openGraph: {
                    url: `${_src_lib_utils__WEBPACK_IMPORTED_MODULE_6__/* .APP_URL */ .FX}/courses/${course.slug}`,
                    title: course.title,
                    description: course.description,
                    images: [
                        {
                            url: `${_src_lib_utils__WEBPACK_IMPORTED_MODULE_6__/* .APP_URL */ .FX}/courses/${course.image}`,
                            alt: `${course.slug}`
                        }, 
                    ]
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Layout__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                border: true,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container my-20",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col md:flex-row items-start gap-8",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-8",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "space-y-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "text-3xl font-semibold",
                                                children: course.title
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "dark:text-slate-400",
                                                children: course.description
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "border rounded-md py-4 px-6",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "dark:text-slate-400 flex flex-wrap gap-5",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(lucide_react__WEBPACK_IMPORTED_MODULE_7__.Users2, {
                                                                    size: 14,
                                                                    className: "text-[#43AF7B]"
                                                                }),
                                                                " কোর্সটি করেছেন 10 জন"
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(lucide_react__WEBPACK_IMPORTED_MODULE_7__.Presentation, {
                                                                    size: 16,
                                                                    className: "text-[#43AF7B]"
                                                                }),
                                                                "মোট 48 টি ক্লাস"
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(lucide_react__WEBPACK_IMPORTED_MODULE_7__.StickyNote, {
                                                                    size: 16,
                                                                    className: "text-[#43AF7B]"
                                                                }),
                                                                " 10 টি নোট"
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(lucide_react__WEBPACK_IMPORTED_MODULE_7__.Video, {
                                                                    size: 16,
                                                                    className: "text-[#43AF7B]"
                                                                }),
                                                                " 10 টি ভিডিও"
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(lucide_react__WEBPACK_IMPORTED_MODULE_7__.Share2, {
                                                                    size: 16,
                                                                    className: "text-[#43AF7B]"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_SocialShare__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                                    url: `${_src_lib_utils__WEBPACK_IMPORTED_MODULE_6__/* .APP_URL */ .FX}/courses/${course.slug}`,
                                                                    title: course.title,
                                                                    description: course.description,
                                                                    hastag: "#ict, #hsc_ict, #freelancing, #skill_development, #web_design, #web_development, #wordpress, #wordpress_theme_development, #wordpress_plugin_development, #react, #nextjs, #nodejs, #mongodb, #mysql"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "space-y-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "text-xl font-semibold",
                                                children: "কোর্সে যা শিখবেন"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "grid lg:grid-cols-2 gap-6",
                                                children: course.topics.length && course.topics.map((topic, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_ListItem__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        children: topic.value
                                                    }, index))
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "space-y-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "text-xl font-semibold",
                                                children: "কোর্স সম্পর্কে বিস্তারিত"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Accordion__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                faqs: course.details
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "grid lg:grid-cols-2 gap-10",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "space-y-3",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                        className: "text-xl font-semibold",
                                                        children: "কোর্সটির জন্য যা যা প্রয়োজন"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "space-y-4",
                                                        children: course.requirements.length && course.requirements.map((requirement, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "dark:text-slate-400 flex items-center gap-3",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(lucide_react__WEBPACK_IMPORTED_MODULE_7__.CheckCheck, {
                                                                        size: 20,
                                                                        className: "text-[#22B995]"
                                                                    }),
                                                                    requirement.value
                                                                ]
                                                            }, index))
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "space-y-3",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                        className: "text-xl font-semibold",
                                                        children: "কোর্সটির করতে যা জানতে হবে"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "space-y-4",
                                                        children: course.knows.length && course.knows.map((know, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "dark:text-slate-400 flex items-center gap-3",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(lucide_react__WEBPACK_IMPORTED_MODULE_7__.CheckCheck, {
                                                                        size: 20,
                                                                        className: "text-[#22B995]"
                                                                    }),
                                                                    know.value
                                                                ]
                                                            }, index))
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "space-y-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "text-xl font-semibold",
                                                children: "কিভাবে কোর্সটি করবেন?"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "space-y-4",
                                                children: course.hows.length && course.hows.map((how, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_ListItem__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        children: how.value
                                                    }, index))
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "space-y-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "text-xl font-semibold",
                                                children: (feedbacks === null || feedbacks === void 0 ? void 0 : feedbacks.data.length) > 0 && "শিক্ষার্থীরা যা বলেছে"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "grid lg:grid-cols-2 gap-4",
                                                children: (feedbacks === null || feedbacks === void 0 ? void 0 : feedbacks.data.length) > 0 && feedbacks.data.map((feedback)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_FeebackItem__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        feedback: feedback
                                                    }, feedback._id))
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-4 md:sticky top-6 md:max-w-[280px] flex-shrink-0",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "text-xl font-semibold",
                                        children: "কোর্স ইন্সট্রাক্টর"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "bg-card border p-6 shadow-sm rounded-md text-center space-y-2 dark:text-slate-400",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                src: "/hazrat.jpg",
                                                width: 120,
                                                height: 120,
                                                alt: "Md Hazrat Ali",
                                                className: "rounded-full"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "dark:text-white text-xl font-semibold",
                                                children: "হযরত আলী"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                children: [
                                                    "ফাউন্ডার অ্যান্ড ডিরেক্টর, আইটিউইন্ডো -",
                                                    " ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                                        children: "একটি ডিজিটাল এজেন্সি"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                children: "ওয়েব ডেভেলপার, এনসিসি, ইউএসএ"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex items-center justify-center gap-4 p-3",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        href: "https://www.facebook.com/webhazrat",
                                                        target: "_blank",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                            src: "/socials/facebook.svg",
                                                            width: 16,
                                                            height: 16,
                                                            alt: "facebook"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        href: "https://twitter.com/webhazrat",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                            src: "/socials/twitter.svg",
                                                            width: 16,
                                                            height: 16,
                                                            alt: "twitter"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        href: "https://www.instagram.com/webhazrat",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                            src: "/socials/instagram.svg",
                                                            width: 16,
                                                            height: 16,
                                                            alt: "twitter"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        href: "https://www.linkedin.com/in/webhazrat/",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                            src: "/socials/linkedin.svg",
                                                            width: 16,
                                                            height: 16,
                                                            alt: "twitter"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        href: "https://www.youtube.com/@y.itwindow",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                            src: "/socials/youtube.svg",
                                                            width: 16,
                                                            height: 16,
                                                            alt: "twitter"
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                href: "https://itwindow.dev/u/webhazrat",
                                                target: "_blank",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_ui_button__WEBPACK_IMPORTED_MODULE_5__/* .Button */ .z, {
                                                    size: "sm",
                                                    variant: "outline",
                                                    className: "rounded-full text-sm",
                                                    children: "আইটিউইন্ডো প্রোফাইল"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "md:relative fixed bottom-0 z-50 left-0 rounded-none w-full flex md:flex-col justify-between gap-3 items-center bg-card border md:rounded-md p-4",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                className: "text-2xl font-medium flex items-center gap-2",
                                                children: [
                                                    "৳",
                                                    course.fee,
                                                    " ",
                                                    course.prevFee > course.fee && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("del", {
                                                        className: "dark:text-slate-400 text-lg",
                                                        children: [
                                                            "৳",
                                                            course.prevFee
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                href: `/enroll/${course.slug}`,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_ui_button__WEBPACK_IMPORTED_MODULE_5__/* .Button */ .z, {
                                                    className: "bg-gradient text-white md:w-full",
                                                    children: "কোর্সটিতে ইনরোল করুন"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
}
const getServerSideProps = async (context)=>{
    const { slug  } = context.query;
    const response = await fetch(`${_src_lib_utils__WEBPACK_IMPORTED_MODULE_6__/* .APP_URL */ .FX}/api/course/${slug}`);
    const courseData = await response.json();
    return {
        props: {
            courseData
        },
        notFound: response.status === 200 ? false : true
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2423:
/***/ ((module) => {

module.exports = require("lucide-react");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 1162:
/***/ ((module) => {

module.exports = require("next-themes");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7412:
/***/ ((module) => {

module.exports = import("@radix-ui/react-accordion");;

/***/ }),

/***/ 7715:
/***/ ((module) => {

module.exports = import("@radix-ui/react-dialog");;

/***/ }),

/***/ 1481:
/***/ ((module) => {

module.exports = import("@radix-ui/react-dropdown-menu");;

/***/ }),

/***/ 6774:
/***/ ((module) => {

module.exports = import("@radix-ui/react-navigation-menu");;

/***/ }),

/***/ 307:
/***/ ((module) => {

module.exports = import("@radix-ui/react-scroll-area");;

/***/ }),

/***/ 4338:
/***/ ((module) => {

module.exports = import("@radix-ui/react-slot");;

/***/ }),

/***/ 6926:
/***/ ((module) => {

module.exports = import("class-variance-authority");;

/***/ }),

/***/ 6593:
/***/ ((module) => {

module.exports = import("clsx");;

/***/ }),

/***/ 5941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ }),

/***/ 8097:
/***/ ((module) => {

module.exports = import("tailwind-merge");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,3061,873,4031,2030,8431,461,7475], () => (__webpack_exec__(6494)));
module.exports = __webpack_exports__;

})();