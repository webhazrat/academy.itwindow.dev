"use strict";
(() => {
var exports = {};
exports.id = 6308;
exports.ids = [6308];
exports.modules = {

/***/ 2031:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ListItem)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2423);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lucide_react__WEBPACK_IMPORTED_MODULE_1__);


function ListItem({ children , className , ...props }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `flex gap-4 ${className}`,
        ...props,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-4 h-4 bg-[#43AF7B] rounded-full flex justify-center items-center flex-shrink-0 mt-1",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(lucide_react__WEBPACK_IMPORTED_MODULE_1__.Check, {
                    size: 14,
                    strokeWidth: 3,
                    className: "text-background"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "dark:text-slate-400",
                children: children
            })
        ]
    });
}


/***/ }),

/***/ 1512:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ReferralEnroll),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _src_components_ListItem__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2031);
/* harmony import */ var _src_components_ProfileLayout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(883);
/* harmony import */ var _src_components_ui_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1276);
/* harmony import */ var _src_hook_useUserProfile__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1509);
/* harmony import */ var _src_lib_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(873);
/* harmony import */ var _src_middleware_clientAuth__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7160);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5941);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_components_ProfileLayout__WEBPACK_IMPORTED_MODULE_2__, _src_components_ui_button__WEBPACK_IMPORTED_MODULE_3__, _src_hook_useUserProfile__WEBPACK_IMPORTED_MODULE_4__, _src_lib_utils__WEBPACK_IMPORTED_MODULE_5__, swr__WEBPACK_IMPORTED_MODULE_8__]);
([_src_components_ProfileLayout__WEBPACK_IMPORTED_MODULE_2__, _src_components_ui_button__WEBPACK_IMPORTED_MODULE_3__, _src_hook_useUserProfile__WEBPACK_IMPORTED_MODULE_4__, _src_lib_utils__WEBPACK_IMPORTED_MODULE_5__, swr__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









function ReferralEnroll() {
    const { user  } = (0,_src_hook_useUserProfile__WEBPACK_IMPORTED_MODULE_4__/* .useUserProfile */ .G)();
    const { data: usersData , isLoading  } = (0,swr__WEBPACK_IMPORTED_MODULE_8__["default"])("/api/user/refer", _src_lib_utils__WEBPACK_IMPORTED_MODULE_5__/* .fetcher */ ._i);
    const users = usersData === null || usersData === void 0 ? void 0 : usersData.data;
    let totalPaidAmmounts = 0;
    users === null || users === void 0 ? void 0 : users.map((user)=>{
        var ref;
        totalPaidAmmounts += (0,_src_lib_utils__WEBPACK_IMPORTED_MODULE_5__/* .total */ .MF)((ref = user.enrollId) === null || ref === void 0 ? void 0 : ref.payments, "Approved");
    });
    const commission = totalPaidAmmounts * (10 / 100);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_ProfileLayout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "text-xl font-medium mb-3",
                        children: "রেফারেল ইনরোল"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "space-y-5",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "bg-card flex flex-col gap-2 rounded-md p-4 max-w-xs",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
                                        children: [
                                            "৳",
                                            commission
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_ui_button__WEBPACK_IMPORTED_MODULE_3__/* .Button */ .z, {
                                        disabled: commission < 100,
                                        className: "bg-gradient text-white",
                                        children: "পে আউট"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "dark:text-slate-400 text-sm",
                                        children: "পে আউট করার জন্য সর্বনিম্ন ৳100 হতে হবে।"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "bg-slate-100 dark:bg-card rounded-md p-4 space-y-4",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_src_components_ListItem__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        children: [
                                            "আপনি যদি কোন শিক্ষর্থীকে আপনার অ্যাকাউন্ট রেফারেল মোবাইল নাম্বার",
                                            " ",
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "dark:text-white",
                                                children: [
                                                    " (",
                                                    user === null || user === void 0 ? void 0 : user.phone,
                                                    ") "
                                                ]
                                            }),
                                            " ",
                                            "ব্যবহার করে সাইন আপ করান এবং পরবর্তীতে সেই শিক্ষার্থী এই প্লাটফর্ম থেকে কোন কোর্স নেন, তাহলে তার কোর্স ফি এর 10% কমিশন অ্যাড হবে আপনার প্রোফাইলে। এবং সর্বনিম্ন 100 টাকা হলে আপনি যেকোন মোবাইল ব্যাংকিং ব্যবহার করে পে আউট করতে পারবেন।"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_src_components_ListItem__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        children: [
                                            "রেফারেলে কোন শিক্ষর্থীকে সাইন আপ করতে সাইন আপ অপশনে গিয়ে",
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "dark:text-white",
                                                children: "[যদি কোন রেফারেল থাকে]"
                                            }),
                                            " ",
                                            "অপশনে এই মোবাইল নাম্বার",
                                            " ",
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "dark:text-white",
                                                children: [
                                                    " (",
                                                    user === null || user === void 0 ? void 0 : user.phone,
                                                    ") "
                                                ]
                                            }),
                                            " ",
                                            "ব্যবহার করতে হবে।"
                                        ]
                                    })
                                ]
                            }),
                            isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Loading..."
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                className: "table-auto border-t border-collapse w-full rounded-md",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    className: "border-b py-2",
                                                    children: "নাম"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    className: "border-b py-2",
                                                    children: "মোবাইল নাম্বার"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    className: "border-b py-2",
                                                    children: "কোর্সের নাম"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    className: "border-b py-2",
                                                    children: "স্ট্যাটাস"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    className: "border-b py-2 text-right",
                                                    children: "পেইড অ্যামাউন্ট"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                        children: (users === null || users === void 0 ? void 0 : users.length) > 0 && users.map((user)=>{
                                            var ref, ref1, ref2, ref3, ref4;
                                            const totalPaidAmmount = (0,_src_lib_utils__WEBPACK_IMPORTED_MODULE_5__/* .total */ .MF)((ref = user.enrollId) === null || ref === void 0 ? void 0 : ref.payments, "Approved");
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                className: "dark:text-slate-400",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "border-b py-2",
                                                        children: user.name
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "border-b py-2",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: `tel:+88${user.phone}`,
                                                            children: user.phone
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "border-b py-2",
                                                        children: (user === null || user === void 0 ? void 0 : (ref1 = user.enrollId) === null || ref1 === void 0 ? void 0 : (ref2 = ref1.courseId) === null || ref2 === void 0 ? void 0 : ref2.title) || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: `border-b py-2 text-sm ${(0,_src_lib_utils__WEBPACK_IMPORTED_MODULE_5__/* .statusColor */ .vm)(user === null || user === void 0 ? void 0 : (ref3 = user.enrollId) === null || ref3 === void 0 ? void 0 : ref3.status)}`,
                                                        children: (user === null || user === void 0 ? void 0 : (ref4 = user.enrollId) === null || ref4 === void 0 ? void 0 : ref4.status) || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "border-b py-2 text-right text-green-400",
                                                        children: totalPaidAmmount
                                                    })
                                                ]
                                            }, user._id);
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
}
async function getServerSideProps(context) {
    return (0,_src_middleware_clientAuth__WEBPACK_IMPORTED_MODULE_6__/* .checkLogin */ .Xx)(context);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2423:
/***/ ((module) => {

module.exports = require("lucide-react");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 1162:
/***/ ((module) => {

module.exports = require("next-themes");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7412:
/***/ ((module) => {

module.exports = import("@radix-ui/react-accordion");;

/***/ }),

/***/ 7715:
/***/ ((module) => {

module.exports = import("@radix-ui/react-dialog");;

/***/ }),

/***/ 1481:
/***/ ((module) => {

module.exports = import("@radix-ui/react-dropdown-menu");;

/***/ }),

/***/ 6774:
/***/ ((module) => {

module.exports = import("@radix-ui/react-navigation-menu");;

/***/ }),

/***/ 307:
/***/ ((module) => {

module.exports = import("@radix-ui/react-scroll-area");;

/***/ }),

/***/ 4338:
/***/ ((module) => {

module.exports = import("@radix-ui/react-slot");;

/***/ }),

/***/ 6926:
/***/ ((module) => {

module.exports = import("class-variance-authority");;

/***/ }),

/***/ 6593:
/***/ ((module) => {

module.exports = import("clsx");;

/***/ }),

/***/ 5941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ }),

/***/ 8097:
/***/ ((module) => {

module.exports = import("tailwind-merge");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,3061,873,4031,2030,7160,8431,461,883], () => (__webpack_exec__(1512)));
module.exports = __webpack_exports__;

})();