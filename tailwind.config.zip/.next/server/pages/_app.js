"use strict";
(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 5261:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FN": () => (/* binding */ Toast),
/* harmony export */   "Mi": () => (/* binding */ ToastTitle),
/* harmony export */   "VW": () => (/* binding */ ToastProvider),
/* harmony export */   "_i": () => (/* binding */ ToastViewport),
/* harmony export */   "lj": () => (/* binding */ ToastDescription),
/* harmony export */   "sA": () => (/* binding */ ToastClose)
/* harmony export */ });
/* unused harmony export ToastAction */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_toast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1329);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6926);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2423);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lucide_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _src_lib_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(873);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_radix_ui_react_toast__WEBPACK_IMPORTED_MODULE_2__, class_variance_authority__WEBPACK_IMPORTED_MODULE_3__, _src_lib_utils__WEBPACK_IMPORTED_MODULE_5__]);
([_radix_ui_react_toast__WEBPACK_IMPORTED_MODULE_2__, class_variance_authority__WEBPACK_IMPORTED_MODULE_3__, _src_lib_utils__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const ToastProvider = _radix_ui_react_toast__WEBPACK_IMPORTED_MODULE_2__.Provider;
const ToastViewport = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className , ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_toast__WEBPACK_IMPORTED_MODULE_2__.Viewport, {
        ref: ref,
        className: (0,_src_lib_utils__WEBPACK_IMPORTED_MODULE_5__.cn)("fixed top-0 z-[100] flex max-h-screen w-full flex-col-reverse p-4 sm:bottom-0 sm:right-0 sm:top-auto sm:flex-col md:max-w-[420px]", className),
        ...props
    }));
ToastViewport.displayName = _radix_ui_react_toast__WEBPACK_IMPORTED_MODULE_2__.Viewport.displayName;
const toastVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_3__.cva)("group pointer-events-auto relative flex w-full items-center justify-between space-x-4 overflow-hidden rounded-md border p-6 pr-8 shadow-lg transition-all data-[swipe=cancel]:translate-x-0 data-[swipe=end]:translate-x-[var(--radix-toast-swipe-end-x)] data-[swipe=move]:translate-x-[var(--radix-toast-swipe-move-x)] data-[swipe=move]:transition-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[swipe=end]:animate-out data-[state=closed]:fade-out-80 data-[state=closed]:slide-out-to-right-full data-[state=open]:slide-in-from-top-full data-[state=open]:sm:slide-in-from-bottom-full", {
    variants: {
        variant: {
            default: "border bg-background text-foreground",
            success: "border bg-background text-green-400",
            destructive: "border bg-background text-red-400"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
// destructive group border-destructive bg-destructive text-destructive-foreground
const Toast = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className , variant , ...props }, ref)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_toast__WEBPACK_IMPORTED_MODULE_2__.Root, {
        ref: ref,
        className: (0,_src_lib_utils__WEBPACK_IMPORTED_MODULE_5__.cn)(toastVariants({
            variant
        }), className),
        ...props
    });
});
Toast.displayName = _radix_ui_react_toast__WEBPACK_IMPORTED_MODULE_2__.Root.displayName;
const ToastAction = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className , ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_toast__WEBPACK_IMPORTED_MODULE_2__.Action, {
        ref: ref,
        className: (0,_src_lib_utils__WEBPACK_IMPORTED_MODULE_5__.cn)("inline-flex h-8 shrink-0 items-center justify-center rounded-md border bg-transparent px-3 text-sm font-medium ring-offset-background transition-colors hover:bg-secondary focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 group-[.destructive]:border-muted/40 group-[.destructive]:hover:border-destructive/30 group-[.destructive]:hover:bg-destructive group-[.destructive]:hover:text-destructive-foreground group-[.destructive]:focus:ring-destructive", className),
        ...props
    }));
ToastAction.displayName = _radix_ui_react_toast__WEBPACK_IMPORTED_MODULE_2__.Action.displayName;
const ToastClose = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className , ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_toast__WEBPACK_IMPORTED_MODULE_2__.Close, {
        ref: ref,
        className: (0,_src_lib_utils__WEBPACK_IMPORTED_MODULE_5__.cn)("absolute right-2 top-2 rounded-md p-1 text-foreground/50 opacity-0 transition-opacity hover:text-foreground focus:opacity-100 focus:outline-none focus:ring-2 group-hover:opacity-100 group-[.destructive]:text-red-300 group-[.destructive]:hover:text-red-50 group-[.destructive]:focus:ring-red-400 group-[.destructive]:focus:ring-offset-red-600", className),
        "toast-close": "",
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(lucide_react__WEBPACK_IMPORTED_MODULE_4__.X, {
            className: "h-4 w-4"
        })
    }));
ToastClose.displayName = _radix_ui_react_toast__WEBPACK_IMPORTED_MODULE_2__.Close.displayName;
const ToastTitle = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className , ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_toast__WEBPACK_IMPORTED_MODULE_2__.Title, {
        ref: ref,
        className: (0,_src_lib_utils__WEBPACK_IMPORTED_MODULE_5__.cn)("text-sm font-semibold", className),
        ...props
    }));
ToastTitle.displayName = _radix_ui_react_toast__WEBPACK_IMPORTED_MODULE_2__.Title.displayName;
const ToastDescription = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className , ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_toast__WEBPACK_IMPORTED_MODULE_2__.Description, {
        ref: ref,
        className: (0,_src_lib_utils__WEBPACK_IMPORTED_MODULE_5__.cn)("text-sm opacity-90", className),
        ...props
    }));
ToastDescription.displayName = _radix_ui_react_toast__WEBPACK_IMPORTED_MODULE_2__.Description.displayName;


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8577:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "x": () => (/* binding */ Toaster)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _src_components_ui_toast__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5261);
/* harmony import */ var _src_components_ui_use_toast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9493);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_components_ui_toast__WEBPACK_IMPORTED_MODULE_1__]);
_src_components_ui_toast__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
"use client";



function Toaster() {
    const { toasts  } = (0,_src_components_ui_use_toast__WEBPACK_IMPORTED_MODULE_2__/* .useToast */ .pm)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_src_components_ui_toast__WEBPACK_IMPORTED_MODULE_1__/* .ToastProvider */ .VW, {
        children: [
            toasts.map(function({ id , title , description , action , ...props }) {
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_src_components_ui_toast__WEBPACK_IMPORTED_MODULE_1__/* .Toast */ .FN, {
                    ...props,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "grid gap-1",
                            children: [
                                title && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_ui_toast__WEBPACK_IMPORTED_MODULE_1__/* .ToastTitle */ .Mi, {
                                    children: title
                                }),
                                description && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_ui_toast__WEBPACK_IMPORTED_MODULE_1__/* .ToastDescription */ .lj, {
                                    children: description
                                })
                            ]
                        }),
                        action,
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_ui_toast__WEBPACK_IMPORTED_MODULE_1__/* .ToastClose */ .sA, {})
                    ]
                }, id);
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_ui_toast__WEBPACK_IMPORTED_MODULE_1__/* .ToastViewport */ ._i, {})
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2654:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_themes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1162);
/* harmony import */ var next_themes__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_themes__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context_UserProfileContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5477);
/* harmony import */ var _components_ui_toaster__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8577);
/* harmony import */ var _context_UserEnrollsContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8185);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6641);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(873);
/* harmony import */ var _context_CoursesContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(44);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_UserProfileContext__WEBPACK_IMPORTED_MODULE_3__, _components_ui_toaster__WEBPACK_IMPORTED_MODULE_4__, _context_UserEnrollsContext__WEBPACK_IMPORTED_MODULE_5__, _lib_utils__WEBPACK_IMPORTED_MODULE_7__, _context_CoursesContext__WEBPACK_IMPORTED_MODULE_8__]);
([_context_UserProfileContext__WEBPACK_IMPORTED_MODULE_3__, _components_ui_toaster__WEBPACK_IMPORTED_MODULE_4__, _context_UserEnrollsContext__WEBPACK_IMPORTED_MODULE_5__, _lib_utils__WEBPACK_IMPORTED_MODULE_7__, _context_CoursesContext__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










function MyApp({ Component , pageProps: { session , ...pageProps }  }) {
    const title = "ITWINDOW - Enhance Yourself";
    const description = "Unlock your potential with ITWINDOW's HSC ICT and freelancing skill development courses. Dive into the world of web design, development, and web application development. Master the art of WordPress theme and plugin development. Elevate your career with hands-on learning and personalized guidance. Join us and empower yourself for success in the ever-evolving landscape of technology and freelancing.";
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_themes__WEBPACK_IMPORTED_MODULE_1__.ThemeProvider, {
        attribute: "class",
        enableSystem: false,
        defaultTheme: "dark",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_auth_react__WEBPACK_IMPORTED_MODULE_2__.SessionProvider, {
            session: session,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_context_CoursesContext__WEBPACK_IMPORTED_MODULE_8__/* .CoursesContextProvider */ .G, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_context_UserProfileContext__WEBPACK_IMPORTED_MODULE_3__/* .UserProfileProvider */ .X, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_context_UserEnrollsContext__WEBPACK_IMPORTED_MODULE_5__/* .UserEnrollsProvider */ .x, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_6__.DefaultSeo, {
                                title: title,
                                description: description,
                                canonical: _lib_utils__WEBPACK_IMPORTED_MODULE_7__/* .APP_URL */ .FX,
                                openGraph: {
                                    url: _lib_utils__WEBPACK_IMPORTED_MODULE_7__/* .APP_URL */ .FX,
                                    title: title,
                                    description: description,
                                    images: [
                                        {
                                            url: `${_lib_utils__WEBPACK_IMPORTED_MODULE_7__/* .APP_URL */ .FX}/itwindow-academy-cover.jpg`,
                                            alt: title
                                        }, 
                                    ]
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                                ...pageProps
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_toaster__WEBPACK_IMPORTED_MODULE_4__/* .Toaster */ .x, {})
                        ]
                    })
                })
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2423:
/***/ ((module) => {

module.exports = require("lucide-react");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 1162:
/***/ ((module) => {

module.exports = require("next-themes");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1329:
/***/ ((module) => {

module.exports = import("@radix-ui/react-toast");;

/***/ }),

/***/ 6926:
/***/ ((module) => {

module.exports = import("class-variance-authority");;

/***/ }),

/***/ 6593:
/***/ ((module) => {

module.exports = import("clsx");;

/***/ }),

/***/ 5941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ }),

/***/ 8097:
/***/ ((module) => {

module.exports = import("tailwind-merge");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [873,8431,9493,8185], () => (__webpack_exec__(2654)));
module.exports = __webpack_exports__;

})();