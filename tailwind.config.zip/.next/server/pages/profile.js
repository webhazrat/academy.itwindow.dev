"use strict";
(() => {
var exports = {};
exports.id = 277;
exports.ids = [277];
exports.modules = {

/***/ 2672:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ProfileEdit)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2423);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lucide_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1276);
/* harmony import */ var _ui_dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6031);
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4230);
/* harmony import */ var _ui_input__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4534);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5641);
/* harmony import */ var _hookform_resolvers_zod__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1656);
/* harmony import */ var _lib_validation__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1839);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _ui_scroll_area__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9465);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ui_button__WEBPACK_IMPORTED_MODULE_2__, _ui_dialog__WEBPACK_IMPORTED_MODULE_3__, _ui_input__WEBPACK_IMPORTED_MODULE_5__, react_hook_form__WEBPACK_IMPORTED_MODULE_6__, _hookform_resolvers_zod__WEBPACK_IMPORTED_MODULE_7__, _lib_validation__WEBPACK_IMPORTED_MODULE_8__, _ui_scroll_area__WEBPACK_IMPORTED_MODULE_10__]);
([_ui_button__WEBPACK_IMPORTED_MODULE_2__, _ui_dialog__WEBPACK_IMPORTED_MODULE_3__, _ui_input__WEBPACK_IMPORTED_MODULE_5__, react_hook_form__WEBPACK_IMPORTED_MODULE_6__, _hookform_resolvers_zod__WEBPACK_IMPORTED_MODULE_7__, _lib_validation__WEBPACK_IMPORTED_MODULE_8__, _ui_scroll_area__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











function ProfileEdit({ user , mutate , onSubmit  }) {
    const { 0: isOpen , 1: setIsOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const { register , handleSubmit , formState: { errors , isSubmitting  } , setError , clearErrors ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_6__.useForm)({
        resolver: (0,_hookform_resolvers_zod__WEBPACK_IMPORTED_MODULE_7__.zodResolver)(_lib_validation__WEBPACK_IMPORTED_MODULE_8__/* .UserSchema */ .c2),
        defaultValues: user
    });
    const handleEditSubmit = async (data)=>{
        const response = await onSubmit(data);
        if (!response.ok) {
            var ref;
            if ((response === null || response === void 0 ? void 0 : (ref = response.errors) === null || ref === void 0 ? void 0 : ref.length) > 0) {
                response.errors.forEach((error)=>{
                    setError(error.field, {
                        type: "server",
                        message: error.message
                    });
                });
            }
        } else {
            mutate();
            setIsOpen(false);
            clearErrors();
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ui_dialog__WEBPACK_IMPORTED_MODULE_3__/* .Dialog */ .Vq, {
        open: isOpen,
        onOpenChange: setIsOpen,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_dialog__WEBPACK_IMPORTED_MODULE_3__/* .DialogTrigger */ .hg, {
                asChild: true,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ui_button__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .z, {
                    size: "sm",
                    variant: "outline",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(lucide_react__WEBPACK_IMPORTED_MODULE_1__.Pencil, {
                            size: 14,
                            className: "mr-2"
                        }),
                        "আপডেট"
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ui_dialog__WEBPACK_IMPORTED_MODULE_3__/* .DialogContent */ .cZ, {
                className: "p-0",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_dialog__WEBPACK_IMPORTED_MODULE_3__/* .DialogHeader */ .fK, {
                        className: "p-7 pb-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_dialog__WEBPACK_IMPORTED_MODULE_3__/* .DialogTitle */ .$N, {
                            children: "প্রোফাইল আপডেট"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_scroll_area__WEBPACK_IMPORTED_MODULE_10__/* .ScrollArea */ .x, {
                        className: "max-h-[calc(100vh_-_200px)] overflow-y-auto mb-16",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "p-7 pt-0",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                onSubmit: handleSubmit(handleEditSubmit),
                                className: "space-y-5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "fixed w-full bottom-0 px-7 left-0 dark:bg-background rounded-b-md z-40 border-t h-16 flex justify-end items-center",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ui_button__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .z, {
                                            type: "submit",
                                            disabled: isSubmitting,
                                            className: "bg-gradient text-white",
                                            children: [
                                                isSubmitting && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(lucide_react__WEBPACK_IMPORTED_MODULE_1__.Loader2, {
                                                    size: 16,
                                                    className: "mr-2 animate-spin"
                                                }),
                                                "সংরক্ষণ"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "space-y-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Label__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                htmlFor: "name",
                                                children: "নাম"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_input__WEBPACK_IMPORTED_MODULE_5__/* .Input */ .I, {
                                                id: "name",
                                                type: "text",
                                                ...register("name")
                                            }),
                                            errors.name && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-sm text-red-400",
                                                children: errors.name.message
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "space-y-2",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Label__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                htmlFor: "email",
                                                children: [
                                                    "ইমেইল ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                                        children: "(যদি থাকে)"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_input__WEBPACK_IMPORTED_MODULE_5__/* .Input */ .I, {
                                                id: "email",
                                                type: "text",
                                                ...register("email")
                                            }),
                                            errors.email && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-sm text-red-400",
                                                children: errors.email.message
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "space-y-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Label__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                htmlFor: "address",
                                                children: "বর্তমান ঠিকানা"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_input__WEBPACK_IMPORTED_MODULE_5__/* .Input */ .I, {
                                                id: "address",
                                                type: "text",
                                                ...register("address")
                                            }),
                                            errors.address && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-sm text-red-400",
                                                children: errors.address.message
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "space-y-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Label__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                htmlFor: "guardian",
                                                children: "অভিভাবকের নাম"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_input__WEBPACK_IMPORTED_MODULE_5__/* .Input */ .I, {
                                                id: "guardian",
                                                type: "text",
                                                ...register("guardian")
                                            }),
                                            errors.guardian && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-sm text-red-400",
                                                children: errors.guardian.message
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "space-y-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Label__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                htmlFor: "guardianPhone",
                                                placeholder: "01XXXXXXXXXXX",
                                                children: "অভিভাবকের মোবাইল নাম্বার"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_input__WEBPACK_IMPORTED_MODULE_5__/* .Input */ .I, {
                                                id: "guardianPhone",
                                                type: "text",
                                                ...register("guardianPhone")
                                            }),
                                            errors.guardianPhone && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-sm text-red-400",
                                                children: errors.guardianPhone.message
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "space-y-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Label__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                htmlFor: "education",
                                                children: "সর্বশেষ শিক্ষাগত যোগ্যতা"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_input__WEBPACK_IMPORTED_MODULE_5__/* .Input */ .I, {
                                                id: "education",
                                                type: "text",
                                                ...register("education")
                                            }),
                                            errors.education && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-sm text-red-400",
                                                children: errors.education.message
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "space-y-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Label__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                htmlFor: "institute",
                                                children: "প্রতিষ্ঠানের নাম"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_input__WEBPACK_IMPORTED_MODULE_5__/* .Input */ .I, {
                                                id: "institute",
                                                type: "text",
                                                ...register("institute")
                                            }),
                                            errors.institute && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-sm text-red-400",
                                                children: errors.institute.message
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 635:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ProfileImage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_easy_crop__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6335);
/* harmony import */ var react_easy_crop__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_easy_crop__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ui_dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6031);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(873);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1276);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2423);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lucide_react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _ui_use_toast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9493);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ui_dialog__WEBPACK_IMPORTED_MODULE_2__, _lib_utils__WEBPACK_IMPORTED_MODULE_4__, _ui_button__WEBPACK_IMPORTED_MODULE_5__]);
([_ui_dialog__WEBPACK_IMPORTED_MODULE_2__, _lib_utils__WEBPACK_IMPORTED_MODULE_4__, _ui_button__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








function ProfileImage({ mutate  }) {
    const { toast  } = (0,_ui_use_toast__WEBPACK_IMPORTED_MODULE_7__/* .useToast */ .pm)();
    const { 0: image , 1: setImage  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        src: "",
        originalname: ""
    });
    const { 0: crop , 1: setCrop  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        x: 0,
        y: 0
    });
    const { 0: zoom , 1: setZoom  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(1);
    const { 0: croppedImage , 1: setCroppedImage  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(null);
    const onCropComplete = async (_, croppedAreaPixels)=>{
        const cropped = await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .getCroppedImg */ .m4)(image.src, croppedAreaPixels);
        setCroppedImage(cropped);
    };
    const handleProfileImage = async ()=>{
        const formData = new FormData();
        formData.append("file", croppedImage, image.originalname);
        try {
            const response = await fetch("/api/user/image", {
                method: "POST",
                body: formData
            });
            const imageResponse = await response.json();
            setImage({
                src: "",
                originalname: ""
            });
            if (response.ok) {
                mutate();
                toast({
                    variant: "success",
                    title: imageResponse.title,
                    description: imageResponse.message
                });
            }
        } catch (error) {
            console.log({
                ProfileImage: error
            });
        }
    };
    const onFileChange = async (e)=>{
        if (e.target.files && e.target.files.length > 0) {
            const file = e.target.files[0];
            if (file.type.startsWith("image/")) {
                const imageDataUrl = await (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__/* .readFile */ .pJ)(file);
                setImage({
                    src: imageDataUrl,
                    originalname: file.name
                });
            } else {
                toast({
                    variant: "destructive",
                    title: "দুঃখিত!",
                    description: "ইমেজ টাইপ ফাইল সিলেক্ট করুন।"
                });
            }
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "absolute -right-1 bottom-1",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                    htmlFor: "photo",
                    className: "rounded-full h-9 w-9 border flex justify-center items-center bg-background cursor-pointer hover:bg-secondary",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(lucide_react__WEBPACK_IMPORTED_MODULE_6__.Pencil, {
                            size: 14
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "file",
                            id: "photo",
                            onChange: onFileChange,
                            className: "hidden"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_dialog__WEBPACK_IMPORTED_MODULE_2__/* .Dialog */ .Vq, {
                open: image.src,
                onOpenChange: setImage,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ui_dialog__WEBPACK_IMPORTED_MODULE_2__/* .DialogContent */ .cZ, {
                    className: "max-w-md",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_dialog__WEBPACK_IMPORTED_MODULE_2__/* .DialogHeader */ .fK, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_dialog__WEBPACK_IMPORTED_MODULE_2__/* .DialogTitle */ .$N, {
                                children: "প্রোফাইল ফটো"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "space-y-4",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "relative w-full h-60 bg-background block",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_easy_crop__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        image: image.src,
                                        crop: crop,
                                        zoom: zoom,
                                        onCropChange: setCrop,
                                        onZoomChange: setZoom,
                                        aspect: 1,
                                        showGrid: false,
                                        onCropComplete: onCropComplete
                                    })
                                }),
                                croppedImage && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_5__/* .Button */ .z, {
                                    onClick: handleProfileImage,
                                    className: "bg-gradient text-white",
                                    children: "আপলোড"
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1765:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Profile),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _src_components_Label__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4230);
/* harmony import */ var _src_components_ProfileEdit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2672);
/* harmony import */ var _src_components_ProfileImage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(635);
/* harmony import */ var _src_components_ProfileLayout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(883);
/* harmony import */ var _src_hook_useUserProfile__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1509);
/* harmony import */ var _src_middleware_clientAuth__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7160);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_components_ProfileEdit__WEBPACK_IMPORTED_MODULE_2__, _src_components_ProfileImage__WEBPACK_IMPORTED_MODULE_3__, _src_components_ProfileLayout__WEBPACK_IMPORTED_MODULE_4__, _src_hook_useUserProfile__WEBPACK_IMPORTED_MODULE_5__]);
([_src_components_ProfileEdit__WEBPACK_IMPORTED_MODULE_2__, _src_components_ProfileImage__WEBPACK_IMPORTED_MODULE_3__, _src_components_ProfileLayout__WEBPACK_IMPORTED_MODULE_4__, _src_hook_useUserProfile__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








function Profile() {
    const { user , isLoading , mutate  } = (0,_src_hook_useUserProfile__WEBPACK_IMPORTED_MODULE_5__/* .useUserProfile */ .G)();
    const imageUrl = (user === null || user === void 0 ? void 0 : user.image) ? `/uploads/${user.image}?v=${Date.now()}` : "/no-photo.png";
    // profile update logic
    const handleProfileUpdate = async (data)=>{
        try {
            const response = await fetch("api/user/update", {
                method: "PUT",
                body: JSON.stringify(data),
                headers: {
                    "Content-Type": "application/json"
                }
            });
            return response;
        } catch (error) {
            console.log({
                profilePage: error
            });
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_ProfileLayout__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                children: "Loading..."
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex justify-between items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-xl font-medium mb-3",
                                children: "প্রোফাইল"
                            }),
                            user && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_ProfileEdit__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                user: user,
                                mutate: mutate,
                                onSubmit: handleProfileUpdate
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-5 items-center",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "relative",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "w-[100px] h-[100px] border rounded-full",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    src: imageUrl,
                                                    width: 150,
                                                    height: 150,
                                                    className: "rounded-full",
                                                    alt: user === null || user === void 0 ? void 0 : user.name
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_ProfileImage__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                mutate: mutate
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                className: "text-lg font-medium",
                                                children: user === null || user === void 0 ? void 0 : user.name
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "dark:text-slate-400 text-[15px]",
                                                children: user === null || user === void 0 ? void 0 : user.phone
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "dark:text-slate-400 text-[15px]",
                                                children: (user === null || user === void 0 ? void 0 : user.email) || "-"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                className: "my-6"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "grid md:grid-cols-2 gap-6",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "space-y-5",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "text-lg font-medium",
                                                children: "ব্যক্তিগত তথ্য"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Label__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                        children: "বর্তমান ঠিকানা :"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "dark:text-slate-400",
                                                        children: (user === null || user === void 0 ? void 0 : user.address) || "-"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Label__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                        children: "অভিভাবকের নাম :"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "dark:text-slate-400",
                                                        children: (user === null || user === void 0 ? void 0 : user.guardian) || "-"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Label__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                        children: "অভিভাবকের মোবাইল নাম্বার :"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "dark:text-slate-400",
                                                        children: (user === null || user === void 0 ? void 0 : user.guardianPhone) || "-"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "space-y-5",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "text-lg font-medium",
                                                children: "শিক্ষাগত তথ্য"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Label__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                        children: "সর্বশেষ শিক্ষাগত যোগ্যতা :"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "dark:text-slate-400",
                                                        children: (user === null || user === void 0 ? void 0 : user.education) || "-"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Label__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                        children: "প্রতিষ্ঠানের নাম :"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "dark:text-slate-400",
                                                        children: (user === null || user === void 0 ? void 0 : user.institute) || "-"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
}
async function getServerSideProps(context) {
    return (0,_src_middleware_clientAuth__WEBPACK_IMPORTED_MODULE_6__/* .checkLogin */ .Xx)(context);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2423:
/***/ ((module) => {

module.exports = require("lucide-react");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 1162:
/***/ ((module) => {

module.exports = require("next-themes");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6335:
/***/ ((module) => {

module.exports = require("react-easy-crop");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1656:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/zod");;

/***/ }),

/***/ 7412:
/***/ ((module) => {

module.exports = import("@radix-ui/react-accordion");;

/***/ }),

/***/ 7715:
/***/ ((module) => {

module.exports = import("@radix-ui/react-dialog");;

/***/ }),

/***/ 1481:
/***/ ((module) => {

module.exports = import("@radix-ui/react-dropdown-menu");;

/***/ }),

/***/ 6774:
/***/ ((module) => {

module.exports = import("@radix-ui/react-navigation-menu");;

/***/ }),

/***/ 307:
/***/ ((module) => {

module.exports = import("@radix-ui/react-scroll-area");;

/***/ }),

/***/ 4338:
/***/ ((module) => {

module.exports = import("@radix-ui/react-slot");;

/***/ }),

/***/ 6926:
/***/ ((module) => {

module.exports = import("class-variance-authority");;

/***/ }),

/***/ 6593:
/***/ ((module) => {

module.exports = import("clsx");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 5941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ }),

/***/ 8097:
/***/ ((module) => {

module.exports = import("tailwind-merge");;

/***/ }),

/***/ 9926:
/***/ ((module) => {

module.exports = import("zod");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,3061,873,4031,2030,7160,8431,461,9493,9327,1839,6031,883], () => (__webpack_exec__(1765)));
module.exports = __webpack_exports__;

})();