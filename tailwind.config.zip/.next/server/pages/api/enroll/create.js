"use strict";
(() => {
var exports = {};
exports.id = 1053;
exports.ids = [1053,3748];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 2113:
/***/ ((module) => {

module.exports = require("next-auth/next");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 6593:
/***/ ((module) => {

module.exports = import("clsx");;

/***/ }),

/***/ 8097:
/***/ ((module) => {

module.exports = import("tailwind-merge");;

/***/ }),

/***/ 9926:
/***/ ((module) => {

module.exports = import("zod");;

/***/ }),

/***/ 5348:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_lib_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(258);
/* harmony import */ var _src_lib_validation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3321);
/* harmony import */ var _src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3935);
/* harmony import */ var _src_models_paymentModel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5697);
/* harmony import */ var _src_models_enrollModel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(742);
/* harmony import */ var zod__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9926);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_lib_validation__WEBPACK_IMPORTED_MODULE_1__, _src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_2__, zod__WEBPACK_IMPORTED_MODULE_5__]);
([_src_lib_validation__WEBPACK_IMPORTED_MODULE_1__, _src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_2__, zod__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






// create a request for enrollment a course path: courses/[slug]
async function handler(req, res) {
    if (req.method === "POST") {
        try {
            const session = await (0,_src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_2__/* .checkLogin */ .Xx)(req, res);
            _src_lib_validation__WEBPACK_IMPORTED_MODULE_1__/* .PaymentSchema.parse */ .tO.parse(req.body);
            let { courseId , paymentMethod , transactionId , fee , amount  } = req.body;
            transactionId = paymentMethod === "Cash" ? "" : transactionId;
            await (0,_src_lib_connect__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)();
            const enrollExist = await _src_models_enrollModel__WEBPACK_IMPORTED_MODULE_4__/* ["default"].countDocuments */ .Z.countDocuments({
                userId: session.user._id,
                courseId,
                status: {
                    $ne: "Ended"
                }
            });
            if (enrollExist) {
                return res.status(400).json({
                    title: "দুঃখিত!",
                    message: "এই কোর্সে পূর্বেই ইনরোল হয়েছেন"
                });
            }
            // is it first course enrollment?
            const exist = await _src_models_enrollModel__WEBPACK_IMPORTED_MODULE_4__/* ["default"].countDocuments */ .Z.countDocuments({
                userId: session.user._id
            });
            const first = exist ? false : true;
            const enroll = await _src_models_enrollModel__WEBPACK_IMPORTED_MODULE_4__/* ["default"].create */ .Z.create({
                userId: session.user._id,
                courseId,
                fee,
                first
            });
            if (enroll) {
                await _src_models_paymentModel__WEBPACK_IMPORTED_MODULE_3__/* ["default"].create */ .Z.create({
                    enrollId: enroll._id,
                    paymentMethod,
                    transactionId,
                    amount
                });
            }
            res.status(200).json({
                title: "সফল!",
                message: "কোর্সে ইনরোল রিকুয়েস্ট সফলভাবে জমা হয়েছে, খুব শীঘ্রই যোগাযোগ করা হবে"
            });
        } catch (error) {
            console.log({
                enrollCreateCatch: error
            });
            // EnrollSchema zod validation error
            if (error instanceof zod__WEBPACK_IMPORTED_MODULE_5__.z.ZodError) {
                return res.status(400).json({
                    errors: error.errors.map((err)=>({
                            field: err.path[0],
                            message: err.message
                        }))
                });
            } else {
                return res.status(500).json({
                    error: "Internal Server Error"
                });
            }
        }
    } else {
        res.status(405).json({
            message: "Request method not allowed"
        });
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3415,3574,3935,3321], () => (__webpack_exec__(5348)));
module.exports = __webpack_exports__;

})();