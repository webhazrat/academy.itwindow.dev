"use strict";
(() => {
var exports = {};
exports.id = 5760;
exports.ids = [5760,3748];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 2113:
/***/ ((module) => {

module.exports = require("next-auth/next");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 6593:
/***/ ((module) => {

module.exports = import("clsx");;

/***/ }),

/***/ 8097:
/***/ ((module) => {

module.exports = import("tailwind-merge");;

/***/ }),

/***/ 8590:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const { Schema  } = (mongoose__WEBPACK_IMPORTED_MODULE_0___default());
const batchSchema = new Schema({
    courseId: {
        type: Schema.Types.ObjectId,
        ref: "Course",
        required: true
    },
    code: {
        type: String,
        required: true
    },
    days: [
        String
    ],
    startDate: Date,
    time: String,
    status: {
        type: String,
        enum: [
            "Pending",
            "Ongoing",
            "Ended"
        ],
        default: "Pending"
    }
}, {
    timestamps: true
});
const batchModel = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Batch) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("Batch", batchSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (batchModel);


/***/ }),

/***/ 8430:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_lib_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(258);
/* harmony import */ var _src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3935);
/* harmony import */ var _src_models_batchModel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8590);
/* harmony import */ var _src_models_courseModel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9953);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_1__]);
_src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




// all batches [path:dashboard/batches]
async function handler(req, res) {
    if (req.method === "GET") {
        const { sortBy , sortOrder , pageIndex , pageSize , search  } = req.query;
        const index = parseInt(pageIndex) || 0;
        const size = parseInt(pageSize) || 10;
        try {
            var ref, ref1;
            const session = await (0,_src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_1__/* .checkAdmin */ .Ax)(req, res);
            const sort = sortBy && sortOrder ? {
                [sortBy]: sortOrder === "asc" ? 1 : -1
            } : {};
            const regex = new RegExp(search, "i");
            const match = {
                $or: [
                    {
                        "courseId.title": {
                            $regex: regex
                        }
                    },
                    {
                        code: {
                            $regex: regex
                        }
                    },
                    {
                        days: {
                            $regex: regex
                        }
                    },
                    {
                        time: {
                            $regex: regex
                        }
                    },
                    {
                        status: {
                            $regex: regex
                        }
                    }, 
                ]
            };
            const aggregationPipeline = [
                {
                    $lookup: {
                        from: "courses",
                        localField: "courseId",
                        foreignField: "_id",
                        as: "courseId"
                    }
                },
                {
                    $unwind: "$courseId"
                },
                {
                    $match: match
                },
                {
                    $sort: sort
                },
                {
                    $skip: index * size
                },
                {
                    $limit: size
                }, 
            ];
            await (0,_src_lib_connect__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)();
            const batches = await _src_models_batchModel__WEBPACK_IMPORTED_MODULE_2__/* ["default"].aggregate */ .Z.aggregate(aggregationPipeline);
            const total = await _src_models_batchModel__WEBPACK_IMPORTED_MODULE_2__/* ["default"].aggregate */ .Z.aggregate([
                ...aggregationPipeline.slice(0, -3),
                {
                    $count: "total"
                }, 
            ]);
            res.status(200).json({
                data: batches,
                total: (ref = total[0]) === null || ref === void 0 ? void 0 : ref.total,
                page: Math.ceil(((ref1 = total[0]) === null || ref1 === void 0 ? void 0 : ref1.total) / size),
                pageSize: size
            });
        } catch (error) {
            console.log({
                batchesCatch: error
            });
            return res.status(500).json({
                status: 500,
                message: "Internal server error"
            });
        }
    } else {
        res.status(405).json({
            status: 405,
            message: "Request method not allowed"
        });
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3415,3574,3935,9953], () => (__webpack_exec__(8430)));
module.exports = __webpack_exports__;

})();