"use strict";
(() => {
var exports = {};
exports.id = 9138;
exports.ids = [9138,3748];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 2113:
/***/ ((module) => {

module.exports = require("next-auth/next");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 6593:
/***/ ((module) => {

module.exports = import("clsx");;

/***/ }),

/***/ 8097:
/***/ ((module) => {

module.exports = import("tailwind-merge");;

/***/ }),

/***/ 9926:
/***/ ((module) => {

module.exports = import("zod");;

/***/ }),

/***/ 4625:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const { Schema  } = (mongoose__WEBPACK_IMPORTED_MODULE_0___default());
const seminarSchema = new Schema({
    title: {
        type: String,
        required: true
    },
    shortDescription: String,
    description: String,
    status: {
        type: String,
        enum: [
            "Published",
            "Unpublished",
            "Ended"
        ],
        default: "Published"
    }
}, {
    timestamps: true
});
const seminarModel = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Seminar) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("Seminar", seminarSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (seminarModel);


/***/ }),

/***/ 6788:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_lib_validation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3321);
/* harmony import */ var _src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3935);
/* harmony import */ var _src_models_seminarModel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4625);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_lib_validation__WEBPACK_IMPORTED_MODULE_0__, _src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_1__]);
([_src_lib_validation__WEBPACK_IMPORTED_MODULE_0__, _src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



// create a seminar [path: dashboard/seminars]
async function handler(req, res) {
    if (req.method === "POST") {
        try {
            const session = await (0,_src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_1__/* .checkAdmin */ .Ax)(req, res);
            _src_lib_validation__WEBPACK_IMPORTED_MODULE_0__/* .SeminarSchema.parse */ .RX.parse(req.body);
            await _src_models_seminarModel__WEBPACK_IMPORTED_MODULE_2__/* ["default"].create */ .Z.create(req.body);
            res.status(200).json({
                title: "সফল!",
                message: "সেমিনার সফলভাবে সংযুক্ত হয়েছে"
            });
        } catch (error) {
            console.log({
                seminarCreateCatch: error
            });
            // SeminarSchema zod validation error
            if (error instanceof z.ZodError) {
                return res.status(400).json({
                    errors: error.errors.map((err)=>({
                            field: err.path[0],
                            message: err.message
                        }))
                });
            } else {
                return res.status(500).json({
                    error: "Internal Server Error"
                });
            }
        }
    } else {
        res.status(405).json({
            message: "Request method not allowed"
        });
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3415,3574,3935,3321], () => (__webpack_exec__(6788)));
module.exports = __webpack_exports__;

})();