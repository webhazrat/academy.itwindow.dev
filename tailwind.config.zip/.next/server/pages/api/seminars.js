"use strict";
(() => {
var exports = {};
exports.id = 9510;
exports.ids = [9510];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 258:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const MONGODB_URL = process.env.MONGODB_URL;
if (!MONGODB_URL) {
    throw new Error("Please define the MONGODB_URL environment variable inside .env.local");
}
let cached = global.mongoose;
if (!cached) {
    cached = global.mongoose = {
        conn: null,
        promise: null
    };
}
async function connectDB() {
    if (cached.conn) {
        return cached.conn;
    }
    if (!cached.promise) {
        const opts = {
            bufferCommands: false
        };
        cached.promise = mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(MONGODB_URL, opts).then((mongoose)=>{
            return mongoose;
        });
    }
    cached.conn = await cached.promise;
    return cached.conn;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (connectDB);


/***/ }),

/***/ 4625:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const { Schema  } = (mongoose__WEBPACK_IMPORTED_MODULE_0___default());
const seminarSchema = new Schema({
    title: {
        type: String,
        required: true
    },
    shortDescription: String,
    description: String,
    status: {
        type: String,
        enum: [
            "Published",
            "Unpublished",
            "Ended"
        ],
        default: "Published"
    }
}, {
    timestamps: true
});
const seminarModel = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Seminar) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("Seminar", seminarSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (seminarModel);


/***/ }),

/***/ 2919:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_lib_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(258);
/* harmony import */ var _src_models_seminarModel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4625);


// all seminars [path:dashboard/seminars]
async function handler(req, res) {
    if (req.method === "GET") {
        const { sortBy , sortOrder , pageIndex , pageSize , search , status  } = req.query;
        const index = parseInt(pageIndex) || 0;
        const size = parseInt(pageSize) || 10;
        try {
            const sort = sortBy && sortOrder ? {
                [sortBy]: sortOrder === "asc" ? 1 : -1
            } : {};
            const regex = new RegExp(search, "i");
            const statusRegex = new RegExp(`^${status}$`, "i");
            const match = {
                $and: [
                    ...status ? [
                        {
                            status: {
                                $regex: statusRegex
                            }
                        }
                    ] : [],
                    {
                        $or: [
                            {
                                title: {
                                    $regex: regex
                                }
                            },
                            {
                                shortDescription: {
                                    $regex: regex
                                }
                            },
                            {
                                status: {
                                    $regex: regex
                                }
                            }, 
                        ]
                    }, 
                ]
            };
            await (0,_src_lib_connect__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)();
            const seminars = await _src_models_seminarModel__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find(match).sort(sort).skip(index * size).limit(size);
            const total = await _src_models_seminarModel__WEBPACK_IMPORTED_MODULE_1__/* ["default"].countDocuments */ .Z.countDocuments(match);
            res.status(200).json({
                data: seminars,
                total,
                page: Math.ceil(total / size),
                pageSize: size
            });
        } catch (error) {
            console.log({
                seminarsCatch: error
            });
            return res.status(500).json({
                status: 500,
                message: "Internal server error"
            });
        }
    } else {
        res.status(405).json({
            status: 405,
            message: "Request method not allowed"
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(2919));
module.exports = __webpack_exports__;

})();