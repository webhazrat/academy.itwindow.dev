"use strict";
(() => {
var exports = {};
exports.id = 2829;
exports.ids = [2829,3748];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 2113:
/***/ ((module) => {

module.exports = require("next-auth/next");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 6593:
/***/ ((module) => {

module.exports = import("clsx");;

/***/ }),

/***/ 8097:
/***/ ((module) => {

module.exports = import("tailwind-merge");;

/***/ }),

/***/ 8924:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_lib_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(258);
/* harmony import */ var _src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3935);
/* harmony import */ var _src_models_userModel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4282);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_1__]);
_src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



async function handler(req, res) {
    if (req.method === "GET") {
        const { sortBy , sortOrder , pageIndex , pageSize , search  } = req.query;
        const index = parseInt(pageIndex) || 0;
        const size = parseInt(pageSize) || 10;
        try {
            const session = await (0,_src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_1__/* .checkAdmin */ .Ax)(req, res);
            const sort = sortBy && sortOrder ? {
                [sortBy]: sortOrder === "asc" ? 1 : -1
            } : {};
            const regex = new RegExp(search, "i");
            const filter = {
                $or: [
                    {
                        name: {
                            $regex: regex
                        }
                    },
                    {
                        phone: {
                            $regex: regex
                        }
                    },
                    {
                        address: {
                            $regex: regex
                        }
                    },
                    {
                        role: {
                            $regex: regex
                        }
                    },
                    {
                        status: {
                            $regex: regex
                        }
                    }, 
                ]
            };
            await (0,_src_lib_connect__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)();
            const users = await _src_models_userModel__WEBPACK_IMPORTED_MODULE_2__/* ["default"].find */ .Z.find(filter).sort(sort).skip(index * size).limit(size);
            const total = await _src_models_userModel__WEBPACK_IMPORTED_MODULE_2__/* ["default"].countDocuments */ .Z.countDocuments(filter);
            res.status(200).json({
                data: users,
                total,
                page: Math.ceil(total / size),
                pageSize: size
            });
        } catch (error) {
            console.log({
                usersCatch: error
            });
            return res.status(500).json({
                status: 500,
                message: "Internal server error"
            });
        }
    } else {
        res.status(405).json({
            status: 405,
            message: "Request method not allowed"
        });
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3415,3574,3935], () => (__webpack_exec__(8924)));
module.exports = __webpack_exports__;

})();