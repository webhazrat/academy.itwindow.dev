"use strict";
(() => {
var exports = {};
exports.id = 332;
exports.ids = [332];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 7146:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const { Schema  } = (mongoose__WEBPACK_IMPORTED_MODULE_0___default());
const feedbackSchema = new Schema({
    courseId: {
        type: Schema.Types.ObjectId,
        ref: "Course",
        required: true
    },
    userId: {
        type: Schema.Types.ObjectId,
        ref: "User",
        required: true
    },
    star: {
        type: String,
        required: true
    },
    comment: String,
    status: {
        type: String,
        enum: [
            "Pending",
            "Approved"
        ],
        default: "Pending"
    }
}, {
    timestamps: true
});
const feedbackModel = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Feedback) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("Feedback", feedbackSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (feedbackModel);


/***/ }),

/***/ 4090:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_lib_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(258);
/* harmony import */ var _src_models_courseModel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9953);
/* harmony import */ var _src_models_feedbackModel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7146);
/* harmony import */ var _src_models_userModel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4282);




// all feedbacks retrieve [path:dashboard/feedbacks]
async function handler(req, res) {
    if (req.method === "GET") {
        const { sortBy , sortOrder , pageIndex , pageSize , search , status  } = req.query;
        const index = parseInt(pageIndex) || 0;
        const size = parseInt(pageSize) || 10;
        try {
            var ref, ref1;
            const sort = sortBy && sortOrder ? {
                [sortBy]: sortOrder === "asc" ? 1 : -1
            } : {};
            const regex = new RegExp(search, "i");
            const statusRegex = new RegExp(`^${status}$`, "i");
            const match = {
                $and: [
                    ...status ? [
                        {
                            status: {
                                $regex: statusRegex
                            }
                        }
                    ] : [],
                    {
                        $or: [
                            {
                                "userId.name": {
                                    $regex: regex
                                }
                            },
                            {
                                "userId.phone": {
                                    $regex: regex
                                }
                            },
                            {
                                "courseId.title": {
                                    $regex: regex
                                }
                            },
                            {
                                status: {
                                    $regex: regex
                                }
                            }, 
                        ]
                    }, 
                ]
            };
            const aggregationPipeline = [
                {
                    $lookup: {
                        from: "users",
                        localField: "userId",
                        foreignField: "_id",
                        as: "userId"
                    }
                },
                {
                    $lookup: {
                        from: "courses",
                        localField: "courseId",
                        foreignField: "_id",
                        as: "courseId"
                    }
                },
                {
                    $unwind: "$userId"
                },
                {
                    $unwind: "$courseId"
                },
                {
                    $match: match
                },
                {
                    $sort: sort
                },
                {
                    $skip: index * size
                },
                {
                    $limit: size
                }, 
            ];
            await (0,_src_lib_connect__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)();
            const feedbacks = await _src_models_feedbackModel__WEBPACK_IMPORTED_MODULE_2__/* ["default"].aggregate */ .Z.aggregate(aggregationPipeline);
            const total = await _src_models_feedbackModel__WEBPACK_IMPORTED_MODULE_2__/* ["default"].aggregate */ .Z.aggregate([
                ...aggregationPipeline.slice(0, -3),
                {
                    $count: "total"
                }, 
            ]);
            res.status(200).json({
                data: feedbacks,
                total: (ref = total[0]) === null || ref === void 0 ? void 0 : ref.total,
                page: Math.ceil(((ref1 = total[0]) === null || ref1 === void 0 ? void 0 : ref1.total) / size),
                pageSize: size
            });
        } catch (error) {
            console.log({
                feedbacksCatch: error
            });
            return res.status(500).json({
                status: 500,
                message: "Internal server error"
            });
        }
    } else {
        res.status(405).json({
            status: 405,
            message: "Request method not allowed"
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3415,9953], () => (__webpack_exec__(4090)));
module.exports = __webpack_exports__;

})();