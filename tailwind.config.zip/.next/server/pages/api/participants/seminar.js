"use strict";
(() => {
var exports = {};
exports.id = 8765;
exports.ids = [8765];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 5735:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_lib_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(258);
/* harmony import */ var _src_models_participantModel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8921);


// seminar wise participants [path:dashboard/participants/[seminarId]]
async function handler(req, res) {
    if (req.method === "GET") {
        const { seminarId , sortBy , sortOrder , pageIndex , pageSize , search  } = req.query;
        const index = parseInt(pageIndex) || 0;
        const size = parseInt(pageSize) || 10;
        try {
            const sort = sortBy && sortOrder ? {
                [sortBy]: sortOrder === "asc" ? 1 : -1
            } : {};
            const regex = new RegExp(search, "i");
            const match = {
                seminarId,
                $or: [
                    {
                        name: {
                            $regex: regex
                        }
                    },
                    {
                        phone: {
                            $regex: regex
                        }
                    },
                    {
                        address: {
                            $regex: regex
                        }
                    },
                    {
                        occupation: {
                            $regex: regex
                        }
                    },
                    {
                        institute: {
                            $regex: regex
                        }
                    }, 
                ]
            };
            await (0,_src_lib_connect__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)();
            const participants = await _src_models_participantModel__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find(match).sort(sort).skip(index * size).limit(size);
            const total = await _src_models_participantModel__WEBPACK_IMPORTED_MODULE_1__/* ["default"].countDocuments */ .Z.countDocuments(match);
            res.status(200).json({
                data: participants,
                total,
                page: Math.ceil(total / size),
                pageSize: size
            });
        } catch (error) {
            console.log({
                participantsSeminarCatch: error
            });
            return res.status(500).json({
                status: 500,
                message: "Internal server error"
            });
        }
    } else {
        res.status(405).json({
            status: 405,
            message: "Request method not allowed"
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2013], () => (__webpack_exec__(5735)));
module.exports = __webpack_exports__;

})();