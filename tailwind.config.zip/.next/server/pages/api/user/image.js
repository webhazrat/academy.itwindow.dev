"use strict";
(() => {
var exports = {};
exports.id = 7873;
exports.ids = [7873,3748];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 2113:
/***/ ((module) => {

module.exports = require("next-auth/next");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 6593:
/***/ ((module) => {

module.exports = import("clsx");;

/***/ }),

/***/ 8097:
/***/ ((module) => {

module.exports = import("tailwind-merge");;

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 7110:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_lib_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(258);
/* harmony import */ var _src_lib_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8742);
/* harmony import */ var _src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3935);
/* harmony import */ var _src_models_userModel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4282);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_2__]);
_src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const config = {
    api: {
        bodyParser: false
    }
};
async function handler(req, res) {
    if (req.method === "POST") {
        const destination = "public/uploads";
        try {
            const session = await (0,_src_middleware_serverAuth__WEBPACK_IMPORTED_MODULE_2__/* .checkLogin */ .Xx)(req, res);
            const upload = await (0,_src_lib_helpers__WEBPACK_IMPORTED_MODULE_1__/* .multerStorage */ .zy)((0,_src_lib_helpers__WEBPACK_IMPORTED_MODULE_1__/* .uId */ .z3)(), destination);
            upload.single("file")(req, {}, async (error)=>{
                if (error) {
                    throw new Error(error);
                }
                await (0,_src_lib_connect__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)();
                const user = await _src_models_userModel__WEBPACK_IMPORTED_MODULE_3__/* ["default"].findById */ .Z.findById(session.user._id).select("image");
                if (user.image) {
                    (0,_src_lib_helpers__WEBPACK_IMPORTED_MODULE_1__/* .unlinkPhoto */ .Vl)(user.image, destination);
                }
                await _src_models_userModel__WEBPACK_IMPORTED_MODULE_3__/* ["default"].updateOne */ .Z.updateOne({
                    _id: session.user._id
                }, {
                    $set: {
                        image: req.file.filename
                    }
                });
                res.status(200).json({
                    title: "সফল!",
                    message: "প্রোফাইল ফটো সফলভাবে আপলোড হয়েছে।"
                });
            });
        } catch (error) {
            console.log({
                profilePhotoCatch: error
            });
            res.status(500).json({
                status: 500,
                message: "Internal server error"
            });
        }
    } else {
        res.status(405).json({
            status: 405,
            message: "Request method not allowed"
        });
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3415,3574,3935,8742], () => (__webpack_exec__(7110)));
module.exports = __webpack_exports__;

})();