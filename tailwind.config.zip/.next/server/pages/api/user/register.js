"use strict";
(() => {
var exports = {};
exports.id = 5310;
exports.ids = [5310];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 9926:
/***/ ((module) => {

module.exports = import("zod");;

/***/ }),

/***/ 8025:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_lib_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(258);
/* harmony import */ var _src_lib_validation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3321);
/* harmony import */ var _src_models_userModel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4282);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8432);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var zod__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9926);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_lib_validation__WEBPACK_IMPORTED_MODULE_1__, zod__WEBPACK_IMPORTED_MODULE_4__]);
([_src_lib_validation__WEBPACK_IMPORTED_MODULE_1__, zod__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





async function handler(req, res) {
    if (req.method === "POST") {
        try {
            _src_lib_validation__WEBPACK_IMPORTED_MODULE_1__/* .UserRegisterSchema.parse */ .Lm.parse(req.body);
            const { phone , token , name , password , refer  } = req.body;
            await (0,_src_lib_connect__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)();
            const hashPassword = bcryptjs__WEBPACK_IMPORTED_MODULE_3___default().hashSync(password, 8);
            // user exist check with phone
            const user = await _src_models_userModel__WEBPACK_IMPORTED_MODULE_2__/* ["default"].findOne */ .Z.findOne({
                phone
            }).select("status token");
            if (user.status === "Verified") {
                return res.status(400).json({
                    errors: [
                        {
                            field: "common",
                            message: "মোবাইল নাম্বার টি ব্যবহার করে পূর্বেই অ্যাকাউন্ট করা হয়েছে।"
                        }, 
                    ]
                });
            }
            if (user.token !== token) {
                return res.status(400).json({
                    errors: [
                        {
                            field: "common",
                            message: "সঠিক OTP ভেরিফাই টোকেন ইনপুট করুন।"
                        }, 
                    ]
                });
            }
            // if has refer
            let userId = null;
            if (refer) {
                const user1 = await _src_models_userModel__WEBPACK_IMPORTED_MODULE_2__/* ["default"].findOne */ .Z.findOne({
                    phone: refer
                }).select("_id");
                if (!user1) {
                    return res.status(400).json({
                        errors: [
                            {
                                field: "refer",
                                message: "মোবাইল নাম্বার টি ব্যবহার করে কোন অ্যাকাউন্ট না থাকায় রেফারেল হিসেবে ব্যবহার করা যাবে না।"
                            }, 
                        ]
                    });
                }
                userId = user1._id;
            }
            // user data update with phone and token
            await _src_models_userModel__WEBPACK_IMPORTED_MODULE_2__/* ["default"].updateOne */ .Z.updateOne({
                phone,
                token
            }, {
                $set: {
                    name,
                    password: hashPassword,
                    refer: userId,
                    status: "Verified"
                },
                $unset: {
                    otp: 1,
                    otpExpires: 1,
                    token: 1
                }
            });
            res.status(200).json({
                status: 200,
                title: "অভিনন্দন!",
                message: "অ্যাকাউন্ট সঠিকভাবে তৈরি হয়েছে।"
            });
        } catch (error) {
            console.log({
                userRegisterCatch: error
            });
            // UserRegisterSchema for zodError
            if (error instanceof zod__WEBPACK_IMPORTED_MODULE_4__.z.ZodError) {
                return res.status(400).json({
                    errors: error.errors.map((err)=>({
                            field: err.path[0],
                            message: err.message
                        }))
                });
            } else {
                return res.status(500).json({
                    error: "Internal Server Error"
                });
            }
        }
    } else {
        res.status(405).json({
            status: 405,
            message: "Request method not allowed"
        });
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3415,3321], () => (__webpack_exec__(8025)));
module.exports = __webpack_exports__;

})();