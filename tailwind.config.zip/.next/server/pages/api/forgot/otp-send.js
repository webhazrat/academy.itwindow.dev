"use strict";
(() => {
var exports = {};
exports.id = 536;
exports.ids = [536];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 9926:
/***/ ((module) => {

module.exports = import("zod");;

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 9590:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_lib_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(258);
/* harmony import */ var _src_lib_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8742);
/* harmony import */ var _src_lib_validation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3321);
/* harmony import */ var _src_models_userModel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4282);
/* harmony import */ var zod__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9926);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_lib_validation__WEBPACK_IMPORTED_MODULE_2__, zod__WEBPACK_IMPORTED_MODULE_4__]);
([_src_lib_validation__WEBPACK_IMPORTED_MODULE_2__, zod__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





async function handler(req, res) {
    if (req.method === "POST") {
        try {
            _src_lib_validation__WEBPACK_IMPORTED_MODULE_2__/* .OtpSendSchema.parse */ .LR.parse(req.body);
            const { phone  } = req.body;
            await (0,_src_lib_connect__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)();
            // user exist check
            const userExist = await _src_models_userModel__WEBPACK_IMPORTED_MODULE_3__/* ["default"].countDocuments */ .Z.countDocuments({
                phone,
                status: "Verified"
            });
            if (!userExist) {
                return res.status(400).json({
                    errors: [
                        {
                            field: "phone",
                            message: "মোবাইল নাম্বার টি ব্যবহার করে কোন অ্যাকাউন্ট করা হয় নাই।"
                        }, 
                    ]
                });
            }
            // otp generate, hash then update or insert to database
            const otp = (0,_src_lib_helpers__WEBPACK_IMPORTED_MODULE_1__/* .generateOTP */ .P)();
            const otpExpires = new Date(Date.now() + 5 * 60 * 1000);
            await _src_models_userModel__WEBPACK_IMPORTED_MODULE_3__/* ["default"].updateOne */ .Z.updateOne({
                phone
            }, {
                otp,
                otpExpires
            });
            // send otp to phone also
            const send = await (0,_src_lib_helpers__WEBPACK_IMPORTED_MODULE_1__/* .sendSMS */ .X)(`88${phone}`, `Your phone verification OTP is ${otp}`);
            if (send.code !== "ok") {
                return res.status(400).json({
                    errors: [
                        {
                            field: "phone",
                            message: "দুঃখিত! মোবাইল নাম্বারটি চেক করে আবার চেষ্টা করুন।"
                        }, 
                    ]
                });
            }
            // final success response
            return res.status(200).json({
                status: 200,
                data: {
                    phone
                },
                tile: "সফল!",
                message: `${phone} মোবাইল নাম্বারে OTP পাঠানো হয়েছে`
            });
        } catch (error) {
            console.log({
                otpSendCatch: error
            });
            // OtpSendSchema zod validation error
            if (error instanceof zod__WEBPACK_IMPORTED_MODULE_4__.z.ZodError) {
                return res.status(400).json({
                    errors: error.errors.map((err)=>({
                            field: err.path[0],
                            message: err.message
                        }))
                });
            } else {
                return res.status(500).json({
                    error: "Internal Server Error"
                });
            }
        }
    } else {
        res.status(405).json({
            status: 405,
            message: "Request method not allowed"
        });
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3415,3321,8742], () => (__webpack_exec__(9590)));
module.exports = __webpack_exports__;

})();