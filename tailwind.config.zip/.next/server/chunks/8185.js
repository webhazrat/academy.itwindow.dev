"use strict";
exports.id = 8185;
exports.ids = [8185];
exports.modules = {

/***/ 8185:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ UserEnrollsContext),
/* harmony export */   "x": () => (/* binding */ UserEnrollsProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5941);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(873);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_2__, _lib_utils__WEBPACK_IMPORTED_MODULE_3__]);
([swr__WEBPACK_IMPORTED_MODULE_2__, _lib_utils__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const UserEnrollsContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
function UserEnrollsProvider({ children  }) {
    var ref;
    const { data: session  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_4__.useSession)();
    const { data: enrolls , isLoading , mutate: enrollsMutate ,  } = (0,swr__WEBPACK_IMPORTED_MODULE_2__["default"])(session ? "/api/enrolls/userId" : null, _lib_utils__WEBPACK_IMPORTED_MODULE_3__/* .fetcher */ ._i);
    const enrollIds = enrolls === null || enrolls === void 0 ? void 0 : (ref = enrolls.data) === null || ref === void 0 ? void 0 : ref.map((enroll)=>enroll._id);
    const { data: payments , mutate: paymentsMutate  } = (0,swr__WEBPACK_IMPORTED_MODULE_2__["default"])((enrollIds === null || enrollIds === void 0 ? void 0 : enrollIds.length) > 0 ? `/api/payment/enroll?enrollId=${enrollIds.join(",")}` : null, _lib_utils__WEBPACK_IMPORTED_MODULE_3__/* .fetcher */ ._i);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UserEnrollsContext.Provider, {
        value: {
            enrollsData: enrolls === null || enrolls === void 0 ? void 0 : enrolls.data,
            paymentsData: payments === null || payments === void 0 ? void 0 : payments.data,
            isLoading,
            enrollsMutate,
            paymentsMutate
        },
        children: children
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;