"use strict";
exports.id = 3935;
exports.ids = [3935];
exports.modules = {

/***/ 866:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* unused harmony exports cn, isActive, APP_URL, OTP_EXPIRE_TIME, fetcher, readFile, getCroppedImg, total, statusColor */
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6593);
/* harmony import */ var tailwind_merge__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8097);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([clsx__WEBPACK_IMPORTED_MODULE_0__, tailwind_merge__WEBPACK_IMPORTED_MODULE_1__]);
([clsx__WEBPACK_IMPORTED_MODULE_0__, tailwind_merge__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


function cn(...inputs) {
    return twMerge(clsx(inputs));
}
const isActive = (path, href)=>{
    return path === href;
};
const APP_URL = "https://academy.itwindow.dev";
const OTP_EXPIRE_TIME = (/* unused pure expression or super */ null && (5 * 60));
// swr fetcher method
const fetcher = async (...args)=>{
    return fetch(...args).then((res)=>res.json());
};
// readfile method for crop image
function readFile(file) {
    return new Promise((resolve)=>{
        const reader = new FileReader();
        reader.addEventListener("load", ()=>resolve(reader.result), false);
        reader.readAsDataURL(file);
    });
}
// croping image method
function getCroppedImg(imageSrc, pixelCrop) {
    const image = new Image();
    image.src = imageSrc;
    const canvas = document.createElement("canvas");
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    canvas.width = 300;
    canvas.height = 300;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(image, pixelCrop.x * scaleX, pixelCrop.y * scaleY, pixelCrop.width * scaleX, pixelCrop.height * scaleY, 0, 0, 300, 300);
    return new Promise((resolve, reject)=>{
        canvas.toBlob((file)=>{
            resolve(file);
        }, "image/jpeg");
    });
}
// total
const total = (payments, status)=>{
    return payments === null || payments === void 0 ? void 0 : payments.reduce((total, payment)=>payment.status === status ? total + Number(payment.amount) : total, 0);
};
// status color
const statusColor = (status)=>{
    const warning = [
        "Pending"
    ];
    const success = [
        "Completed",
        "Approved",
        "Verified",
        "Ongoing",
        "Ended",
        "Published", 
    ];
    const danger = [
        "Unverified",
        "Unpublished",
        "Canceled"
    ];
    if (warning.includes(status)) {
        return "text-yellow-400";
    }
    if (success.includes(status)) {
        return "text-green-400";
    }
    if (danger.includes(status)) {
        return "text-red-400";
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3935:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ax": () => (/* binding */ checkAdmin),
/* harmony export */   "KV": () => (/* binding */ checkEnroll),
/* harmony export */   "Xx": () => (/* binding */ checkLogin)
/* harmony export */ });
/* harmony import */ var next_auth_next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2113);
/* harmony import */ var next_auth_next__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth_next__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pages_api_auth_nextauth___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3574);
/* harmony import */ var _lib_connect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(258);
/* harmony import */ var _models_userModel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4282);
/* harmony import */ var _models_enrollModel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(742);
/* harmony import */ var _models_paymentModel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5697);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(866);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_utils__WEBPACK_IMPORTED_MODULE_6__]);
_lib_utils__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







async function checkAdmin(req, res) {
    const session = await (0,next_auth_next__WEBPACK_IMPORTED_MODULE_0__.getServerSession)(req, res, _pages_api_auth_nextauth___WEBPACK_IMPORTED_MODULE_1__.authOptions);
    if (session) {
        await (0,_lib_connect__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
        const user = await _models_userModel__WEBPACK_IMPORTED_MODULE_3__/* ["default"].findById */ .Z.findById(session.user._id).select("role");
        if (user.role === "Admin") {
            return Promise.resolve(session);
        } else {
            return Promise.reject({
                message: "Unauthorized route"
            });
        }
    }
    return Promise.reject({
        message: "Unauthorized route"
    });
}
async function checkLogin(req, res) {
    const session = await (0,next_auth_next__WEBPACK_IMPORTED_MODULE_0__.getServerSession)(req, res, _pages_api_auth_nextauth___WEBPACK_IMPORTED_MODULE_1__.authOptions);
    if (session) {
        return Promise.resolve(session);
    }
    return Promise.reject({
        message: "Unauthorized route"
    });
}
async function checkEnroll(req, res, enrollIds) {
    const session = await (0,next_auth_next__WEBPACK_IMPORTED_MODULE_0__.getServerSession)(req, res, _pages_api_auth_nextauth___WEBPACK_IMPORTED_MODULE_1__.authOptions);
    if (session) {
        await (0,_lib_connect__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
        const user = await _models_userModel__WEBPACK_IMPORTED_MODULE_3__/* ["default"].findById */ .Z.findById(session.user._id).select("role");
        if (user.role === "Admin") {
            return Promise.resolve(session);
        } else {
            const enrolls = await _models_enrollModel__WEBPACK_IMPORTED_MODULE_4__/* ["default"].find */ .Z.find({
                userId: session.user._id
            }).select("_id");
            const enrollIdsInc = enrollIds.some((id)=>enrolls.some((enroll)=>enroll._id.toString() === id));
            if (enrollIdsInc) {
                return Promise.resolve(session);
            } else {
                return Promise.reject({
                    message: "Unauthorized route"
                });
            }
        }
    }
    return Promise.reject({
        message: "Unauthorized route"
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 742:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const { Schema  } = (mongoose__WEBPACK_IMPORTED_MODULE_0___default());
const enrollSchema = new Schema({
    userId: {
        type: Schema.Types.ObjectId,
        ref: "User",
        required: true
    },
    courseId: {
        type: Schema.Types.ObjectId,
        ref: "Course",
        required: true
    },
    batchId: {
        type: Schema.Types.ObjectId,
        ref: "Batch"
    },
    fee: {
        type: String,
        required: true
    },
    first: Boolean,
    status: {
        type: String,
        required: true,
        enum: [
            "Pending",
            "Completed",
            "Ended"
        ],
        default: "Pending"
    }
}, {
    timestamps: true
});
const enrollModel = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Enroll) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("Enroll", enrollSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (enrollModel);


/***/ }),

/***/ 5697:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const { Schema  } = (mongoose__WEBPACK_IMPORTED_MODULE_0___default());
const paymentSchema = new Schema({
    enrollId: {
        type: Schema.Types.ObjectId,
        ref: "Enroll",
        required: true
    },
    paymentMethod: String,
    transactionId: String,
    amount: String,
    comment: String,
    status: {
        type: String,
        default: "Pending"
    }
}, {
    timestamps: true
});
const paymentModel = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Payment) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("Payment", paymentSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (paymentModel);


/***/ })

};
;