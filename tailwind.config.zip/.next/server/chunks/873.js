"use strict";
exports.id = 873;
exports.ids = [873];
exports.modules = {

/***/ 873:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FX": () => (/* binding */ APP_URL),
/* harmony export */   "MF": () => (/* binding */ total),
/* harmony export */   "_i": () => (/* binding */ fetcher),
/* harmony export */   "cn": () => (/* binding */ cn),
/* harmony export */   "l1": () => (/* binding */ OTP_EXPIRE_TIME),
/* harmony export */   "m4": () => (/* binding */ getCroppedImg),
/* harmony export */   "pJ": () => (/* binding */ readFile),
/* harmony export */   "vm": () => (/* binding */ statusColor),
/* harmony export */   "zh": () => (/* binding */ isActive)
/* harmony export */ });
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6593);
/* harmony import */ var tailwind_merge__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8097);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([clsx__WEBPACK_IMPORTED_MODULE_0__, tailwind_merge__WEBPACK_IMPORTED_MODULE_1__]);
([clsx__WEBPACK_IMPORTED_MODULE_0__, tailwind_merge__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


function cn(...inputs) {
    return (0,tailwind_merge__WEBPACK_IMPORTED_MODULE_1__.twMerge)((0,clsx__WEBPACK_IMPORTED_MODULE_0__.clsx)(inputs));
}
const isActive = (path, href)=>{
    return path === href;
};
const APP_URL = "https://academy.itwindow.dev";
const OTP_EXPIRE_TIME = 5 * 60;
// swr fetcher method
const fetcher = async (...args)=>{
    return fetch(...args).then((res)=>res.json());
};
// readfile method for crop image
function readFile(file) {
    return new Promise((resolve)=>{
        const reader = new FileReader();
        reader.addEventListener("load", ()=>resolve(reader.result), false);
        reader.readAsDataURL(file);
    });
}
// croping image method
function getCroppedImg(imageSrc, pixelCrop) {
    const image = new Image();
    image.src = imageSrc;
    const canvas = document.createElement("canvas");
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    canvas.width = 300;
    canvas.height = 300;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(image, pixelCrop.x * scaleX, pixelCrop.y * scaleY, pixelCrop.width * scaleX, pixelCrop.height * scaleY, 0, 0, 300, 300);
    return new Promise((resolve, reject)=>{
        canvas.toBlob((file)=>{
            resolve(file);
        }, "image/jpeg");
    });
}
// total
const total = (payments, status)=>{
    return payments === null || payments === void 0 ? void 0 : payments.reduce((total, payment)=>payment.status === status ? total + Number(payment.amount) : total, 0);
};
// status color
const statusColor = (status)=>{
    const warning = [
        "Pending"
    ];
    const success = [
        "Completed",
        "Approved",
        "Verified",
        "Ongoing",
        "Ended",
        "Published", 
    ];
    const danger = [
        "Unverified",
        "Unpublished",
        "Canceled"
    ];
    if (warning.includes(status)) {
        return "text-yellow-400";
    }
    if (success.includes(status)) {
        return "text-green-400";
    }
    if (danger.includes(status)) {
        return "text-red-400";
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;