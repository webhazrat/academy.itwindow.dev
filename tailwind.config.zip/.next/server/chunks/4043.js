"use strict";
exports.id = 4043;
exports.ids = [4043];
exports.modules = {

/***/ 7768:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ OtpSend)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5641);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2423);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lucide_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hookform_resolvers_zod__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1656);
/* harmony import */ var _lib_validation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1839);
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4230);
/* harmony import */ var _ui_input__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4534);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1276);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_1__, _hookform_resolvers_zod__WEBPACK_IMPORTED_MODULE_3__, _lib_validation__WEBPACK_IMPORTED_MODULE_4__, _ui_input__WEBPACK_IMPORTED_MODULE_6__, _ui_button__WEBPACK_IMPORTED_MODULE_7__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_1__, _hookform_resolvers_zod__WEBPACK_IMPORTED_MODULE_3__, _lib_validation__WEBPACK_IMPORTED_MODULE_4__, _ui_input__WEBPACK_IMPORTED_MODULE_6__, _ui_button__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








function OtpSend({ handleOtpSend , comment  }) {
    const { register , handleSubmit , formState: { errors , isSubmitting  } , setError , clearErrors ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useForm)({
        resolver: (0,_hookform_resolvers_zod__WEBPACK_IMPORTED_MODULE_3__.zodResolver)(_lib_validation__WEBPACK_IMPORTED_MODULE_4__/* .OtpSendSchema */ .LR)
    });
    const handleNext = async (data)=>{
        var ref;
        const response = await handleOtpSend(data);
        if ((response === null || response === void 0 ? void 0 : (ref = response.errors) === null || ref === void 0 ? void 0 : ref.length) > 0) {
            response.errors.forEach((error)=>{
                setError(error.field, {
                    type: "server",
                    message: error.message
                });
            });
        } else {
            clearErrors();
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
        onSubmit: handleSubmit(handleNext),
        className: "space-y-4",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "space-y-3",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Label__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                className: "font-medium",
                                htmlFor: "phone",
                                children: "মোবাইল নাম্বার"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-sm dark:text-slate-400",
                                children: comment
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_input__WEBPACK_IMPORTED_MODULE_6__/* .Input */ .I, {
                        id: "phone",
                        type: "text",
                        ...register("phone"),
                        placeholder: "01XXXXXXXXX"
                    }),
                    errors.phone && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "text-sm dark:text-red-400",
                        children: errors.phone.message
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ui_button__WEBPACK_IMPORTED_MODULE_7__/* .Button */ .z, {
                type: "submit",
                disabled: isSubmitting,
                className: "bg-gradient text-white",
                children: [
                    isSubmitting && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(lucide_react__WEBPACK_IMPORTED_MODULE_2__.Loader2, {
                        size: 16,
                        className: "mr-2 animate-spin"
                    }),
                    "এগিয়ে যান"
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6919:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ OtpVerify)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2423);
/* harmony import */ var lucide_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lucide_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1276);
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4230);
/* harmony import */ var _ui_input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4534);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5641);
/* harmony import */ var _ui_use_toast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9493);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(873);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ui_button__WEBPACK_IMPORTED_MODULE_2__, _ui_input__WEBPACK_IMPORTED_MODULE_4__, react_hook_form__WEBPACK_IMPORTED_MODULE_6__, _lib_utils__WEBPACK_IMPORTED_MODULE_8__]);
([_ui_button__WEBPACK_IMPORTED_MODULE_2__, _ui_input__WEBPACK_IMPORTED_MODULE_4__, react_hook_form__WEBPACK_IMPORTED_MODULE_6__, _lib_utils__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









function OtpVerify({ phone , handleOtpVerify , handleOtpSend  }) {
    const { 0: remainingTime , 1: setRemainingTime  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(_lib_utils__WEBPACK_IMPORTED_MODULE_8__/* .OTP_EXPIRE_TIME */ .l1);
    const timerRef = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)();
    const inputRefs = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)([]);
    const { register , handleSubmit , formState: { errors , isSubmitting  } , setValue , setError , clearErrors ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_6__.useForm)();
    const { toast  } = (0,_ui_use_toast__WEBPACK_IMPORTED_MODULE_7__/* .useToast */ .pm)();
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        clearInterval(timerRef.current);
        if (remainingTime > 0) {
            timerRef.current = setInterval(()=>{
                setRemainingTime((time)=>time - 1);
            }, 1000);
        }
        return ()=>clearInterval(timerRef.current);
    }, [
        remainingTime
    ]);
    const minutes = Math.floor(remainingTime / 60);
    const seconds = remainingTime % 60;
    // otp send again
    const otpSendAgain = async ()=>{
        var ref;
        clearErrors();
        const response = await handleOtpSend({
            phone
        });
        if (!(response === null || response === void 0 ? void 0 : (ref = response.errors) === null || ref === void 0 ? void 0 : ref.length) > 0) {
            setRemainingTime(_lib_utils__WEBPACK_IMPORTED_MODULE_8__/* .OTP_EXPIRE_TIME */ .l1);
            toast({
                variant: "success",
                title: "সফল!",
                description: `${phone} নাম্বারে OTP পাঠানো হয়েছে।`
            });
        }
    };
    const handleOtpSubmit = async (data)=>{
        var ref;
        const otp = `${data.otp1}${data.otp2}${data.otp3}${data.otp4}`;
        const response = await handleOtpVerify({
            phone,
            otp
        });
        if ((response === null || response === void 0 ? void 0 : (ref = response.errors) === null || ref === void 0 ? void 0 : ref.length) > 0) {
            response.errors.forEach((error)=>{
                setError(error.field, {
                    type: "server",
                    message: error.message
                });
            });
        }
    };
    const handleChange = (e, index)=>{
        clearErrors();
        const value = e.target.value;
        if (isNaN(value)) return false;
        setValue(`otp${index}`, value);
        if (index < 4 && value) {
            inputRefs.current[index + 1].focus();
        }
    };
    const handleBackspace = (e, index)=>{
        clearErrors();
        if (e.key === "Backspace" && !e.target.value) {
            var ref;
            (ref = inputRefs.current[index - 1]) === null || ref === void 0 ? void 0 : ref.focus();
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
            className: "space-y-3",
            onSubmit: handleSubmit(handleOtpSubmit),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Label__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    className: "font-medium",
                    children: "মোবাইল নাম্বার ভেরিফাই করুন"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    className: "text-sm dark:text-slate-400",
                    children: [
                        phone,
                        " নাম্বারে 4 সংখ্যার কোড পাঠানো হয়েছে। কোডটি এখানে ইনপুট করুন।"
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex gap-5",
                    children: [
                        1,
                        2,
                        3,
                        4
                    ].map((index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_input__WEBPACK_IMPORTED_MODULE_4__/* .Input */ .I, {
                            id: `otp${index}`,
                            ...register(`otp${index}`, {
                                required: true
                            }),
                            onChange: (e)=>handleChange(e, index),
                            onKeyDown: (e)=>handleBackspace(e, index),
                            ref: (el)=>inputRefs.current[index] = el,
                            maxLength: "1",
                            type: "text",
                            className: "aspect-video h-auto text-2xl text-center"
                        }, index))
                }),
                (errors.otp1 || errors.otp2 || errors.otp3 || errors.otp4) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "text-sm text-red-400",
                    children: "4 সংখ্যার OTP টি ইনপুট করুন।"
                }),
                errors.otp && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "text-sm text-red-400",
                    children: errors.otp.message
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-between items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: remainingTime !== 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                children: [
                                    "অবশিষ্ট সময় ",
                                    minutes,
                                    ":",
                                    seconds < 10 ? "0" : "",
                                    seconds
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .z, {
                            type: "button",
                            variant: "link",
                            disabled: remainingTime !== 0,
                            className: `p-0 h-auto`,
                            onClick: otpSendAgain,
                            children: "আবার কোড পাঠান"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ui_button__WEBPACK_IMPORTED_MODULE_2__/* .Button */ .z, {
                    type: "submit",
                    disabled: isSubmitting,
                    className: "bg-gradient text-white",
                    children: [
                        isSubmitting && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(lucide_react__WEBPACK_IMPORTED_MODULE_1__.Loader2, {
                            size: 16,
                            className: "mr-2 animate-spin"
                        }),
                        "ভেরিফাই করুন"
                    ]
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;