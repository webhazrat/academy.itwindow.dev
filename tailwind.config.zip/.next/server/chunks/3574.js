"use strict";
exports.id = 3574;
exports.ids = [3574];
exports.modules = {

/***/ 3574:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "authOptions": () => (/* binding */ authOptions),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _src_models_userModel__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4282);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3227);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7449);
/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8432);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _src_lib_connect__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(258);





const authOptions = {
    providers: [
        next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_2___default()({
            name: "Credentials",
            async authorize (credentials) {
                const { phone , password  } = credentials;
                await (0,_src_lib_connect__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
                const user = await _src_models_userModel__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findOne */ .Z.findOne({
                    phone
                });
                if (!user) {
                    return Promise.reject({
                        message: "এই নাম্বার ব্যবহার করে কোন অ্যাকাউন্ট নাই।"
                    });
                } else {
                    if (user && bcryptjs__WEBPACK_IMPORTED_MODULE_3___default().compareSync(password, user.password)) {
                        return Promise.resolve(user);
                    } else {
                        return Promise.reject({
                            message: "মোবাইল ও পাসওয়ার্ড মিল হচ্ছে না।"
                        });
                    }
                }
            }
        }), 
    ],
    pages: {
        signIn: "/login",
        error: "/login"
    },
    callbacks: {
        async jwt ({ token , user  }) {
            if (user) {
                token._id = user._id;
            }
            return token;
        },
        async session ({ session , token  }) {
            session.user._id = token._id;
            return session;
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_auth__WEBPACK_IMPORTED_MODULE_1___default()(authOptions));


/***/ })

};
;