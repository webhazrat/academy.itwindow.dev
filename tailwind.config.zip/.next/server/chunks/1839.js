"use strict";
exports.id = 1839;
exports.ids = [1839];
exports.modules = {

/***/ 1839:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FT": () => (/* binding */ FeedbackSchema),
/* harmony export */   "HQ": () => (/* binding */ ChangePasswordSchema),
/* harmony export */   "I3": () => (/* binding */ CourseSchema),
/* harmony export */   "LR": () => (/* binding */ OtpSendSchema),
/* harmony export */   "Lm": () => (/* binding */ UserRegisterSchema),
/* harmony export */   "RX": () => (/* binding */ SeminarSchema),
/* harmony export */   "Zr": () => (/* binding */ BatchEnrollSchema),
/* harmony export */   "c2": () => (/* binding */ UserSchema),
/* harmony export */   "g1": () => (/* binding */ ParticipantSchema),
/* harmony export */   "m2": () => (/* binding */ BatchSchema),
/* harmony export */   "pj": () => (/* binding */ LoginSchema),
/* harmony export */   "sw": () => (/* binding */ ForgotPasswordSchema),
/* harmony export */   "tO": () => (/* binding */ PaymentSchema),
/* harmony export */   "yf": () => (/* binding */ CourseImageSchema)
/* harmony export */ });
/* harmony import */ var zod__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9926);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([zod__WEBPACK_IMPORTED_MODULE_0__]);
zod__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const OtpSendSchema = zod__WEBPACK_IMPORTED_MODULE_0__.object({
    phone: zod__WEBPACK_IMPORTED_MODULE_0__.string().regex(/^(01[3456789]\d{8})$/, "সঠিক মোবাইল নাম্বার ইনপুট করুন")
});
const UserRegisterSchema = zod__WEBPACK_IMPORTED_MODULE_0__.object({
    name: zod__WEBPACK_IMPORTED_MODULE_0__.string().refine((data)=>data.trim() !== "", {
        message: "পুরো নাম ইনপুট করুন"
    }),
    password: zod__WEBPACK_IMPORTED_MODULE_0__.string().min(8, "পাসওয়ার্ড কমপক্ষে আট অক্ষরের হতে হবে"),
    confirmPassword: zod__WEBPACK_IMPORTED_MODULE_0__.string(),
    refer: zod__WEBPACK_IMPORTED_MODULE_0__.string().optional().refine((phone)=>phone === "" || phone === undefined || /^(01[3456789]\d{8})$/.test(phone), {
        message: "সঠিক মোবাইল নাম্বার ইনপুট করুন"
    }),
    terms: zod__WEBPACK_IMPORTED_MODULE_0__.boolean().default(false).refine((data)=>data === true, {
        message: "আপনাকে অবশ্যই শর্তাবলী মেনে নিতে হবে"
    })
}).refine((data)=>data.password === data.confirmPassword, {
    message: "অবশ্যই উপরের পাসওয়ার্ডে সাথে মিলতে হবে",
    path: [
        "confirmPassword"
    ]
});
// forgot password form validation
const ForgotPasswordSchema = zod__WEBPACK_IMPORTED_MODULE_0__.object({
    password: zod__WEBPACK_IMPORTED_MODULE_0__.string().min(8, "পাসওয়ার্ড কমপক্ষে আট অক্ষরের হতে হবে"),
    confirmPassword: zod__WEBPACK_IMPORTED_MODULE_0__.string()
}).refine((data)=>data.password === data.confirmPassword, {
    message: "অবশ্যই উপরের পাসওয়ার্ডে সাথে মিলতে হবে",
    path: [
        "confirmPassword"
    ]
});
// login form validation
const LoginSchema = zod__WEBPACK_IMPORTED_MODULE_0__.object({
    phone: zod__WEBPACK_IMPORTED_MODULE_0__.string().regex(/^(01[3456789]\d{8})$/, "সঠিক মোবাইল নাম্বার ইনপুট করুন"),
    password: zod__WEBPACK_IMPORTED_MODULE_0__.string().refine((data)=>data.trim() !== "", {
        message: "পাসওয়ার্ড ইনপুট করুন"
    })
});
// user profile update
const UserSchema = zod__WEBPACK_IMPORTED_MODULE_0__.object({
    name: zod__WEBPACK_IMPORTED_MODULE_0__.string().refine((data)=>data.trim() !== "", {
        message: "পুরো নাম ইনপুট করুন"
    }),
    email: zod__WEBPACK_IMPORTED_MODULE_0__.string().refine((data)=>data === "" || zod__WEBPACK_IMPORTED_MODULE_0__.string().email().safeParse(data).success, {
        message: "সঠিক ইমেল অ্যাড্রেস ইনপুট করুন।"
    }).optional(),
    address: zod__WEBPACK_IMPORTED_MODULE_0__.string().refine((data)=>data.trim() !== "", {
        message: "বর্তমান ঠিকানা ইনপুট করুন"
    }),
    guardian: zod__WEBPACK_IMPORTED_MODULE_0__.string().refine((data)=>data.trim() !== "", {
        message: "অভিভাবকের ইনপুট করুন"
    }),
    guardianPhone: zod__WEBPACK_IMPORTED_MODULE_0__.string().regex(/^(01[3456789]\d{8})$/, "অভিভাবকের সঠিক মোবাইল নাম্বার ইনপুট করুন"),
    education: zod__WEBPACK_IMPORTED_MODULE_0__.string().refine((data)=>data.trim() !== "", {
        message: "সর্বশেষ শিক্ষাগত যোগ্যতা ইনপুট করুন"
    }),
    institute: zod__WEBPACK_IMPORTED_MODULE_0__.string().refine((data)=>data.trim() !== "", {
        message: "প্রতিষ্ঠানের নাম ইনপুট করুন"
    })
});
// course submit form validation
const CourseSchema = zod__WEBPACK_IMPORTED_MODULE_0__.object({
    title: zod__WEBPACK_IMPORTED_MODULE_0__.string().min(1, "কোর্স টাইটেল ইনপুট করুন"),
    slug: zod__WEBPACK_IMPORTED_MODULE_0__.string().regex(/^[a-z0-9-]+$/, "সঠিক স্লাগ ইনপুট করুন"),
    excerpt: zod__WEBPACK_IMPORTED_MODULE_0__.string().min(1, "ছোট বিবরণ ইনপুট করুন"),
    description: zod__WEBPACK_IMPORTED_MODULE_0__.string().min(1, "বিবরণ ইনপুট করুন"),
    topics: zod__WEBPACK_IMPORTED_MODULE_0__.array(zod__WEBPACK_IMPORTED_MODULE_0__.object({
        value: zod__WEBPACK_IMPORTED_MODULE_0__.string().min(1, "কোর্সে শিক্ষানীয় বিষয় ইনপুট করুন")
    })),
    details: zod__WEBPACK_IMPORTED_MODULE_0__.array(zod__WEBPACK_IMPORTED_MODULE_0__.object({
        question: zod__WEBPACK_IMPORTED_MODULE_0__.string().min(1, "কোর্সের বিস্তারিত ইনপুট করুন"),
        answer: zod__WEBPACK_IMPORTED_MODULE_0__.string().min(1, "কোর্সের বিস্তারিত ইনপুট করুন")
    })),
    requirements: zod__WEBPACK_IMPORTED_MODULE_0__.array(zod__WEBPACK_IMPORTED_MODULE_0__.object({
        value: zod__WEBPACK_IMPORTED_MODULE_0__.string().min(1, "কোর্স করতে প্রয়োজনীয় বিষয় ইনপুট করুন")
    })),
    knows: zod__WEBPACK_IMPORTED_MODULE_0__.array(zod__WEBPACK_IMPORTED_MODULE_0__.object({
        value: zod__WEBPACK_IMPORTED_MODULE_0__.string().min(1, "কোর্স করতে জ্ঞাত বিষয় ইনপুট করুন")
    })),
    hows: zod__WEBPACK_IMPORTED_MODULE_0__.array(zod__WEBPACK_IMPORTED_MODULE_0__.object({
        value: zod__WEBPACK_IMPORTED_MODULE_0__.string().min(1, "কোর্সটি কিভাবে করবে তা ইনপুট করুন")
    })),
    fee: zod__WEBPACK_IMPORTED_MODULE_0__.string().min(1, "কোর্স ফি ইনপুট করুন").refine((value)=>!isNaN(value), {
        message: "কোর্স ফি নাম্বারে ইনপুট করুন"
    }),
    prevFee: zod__WEBPACK_IMPORTED_MODULE_0__.string().optional(),
    status: zod__WEBPACK_IMPORTED_MODULE_0__.string().optional(),
    order: zod__WEBPACK_IMPORTED_MODULE_0__.string().optional()
});
// course image form validation
const CourseImageSchema = zod__WEBPACK_IMPORTED_MODULE_0__.object({
    icon: zod__WEBPACK_IMPORTED_MODULE_0__.any().refine((icon)=>{
        if (icon && (!icon.type.startsWith("image/") || icon.size > 1 * 1024 * 1024)) {
            return false;
        }
        return true;
    }, {
        message: "আইকন টাইপ (jpg, jpeg, png or svg) এবং সাইজ 1MB এর কম হতে হবে"
    }),
    image: zod__WEBPACK_IMPORTED_MODULE_0__.any().refine((image)=>{
        if (image && (!image.type.startsWith("image/") || image.size > 1 * 1024 * 1024)) {
            return false;
        }
        return true;
    }, {
        message: "ইমেজ টাইপ (jpg, jpeg, png or svg) এবং সাইজ 1MB এর কম হতে হবে"
    })
});
// password change form validation
const ChangePasswordSchema = zod__WEBPACK_IMPORTED_MODULE_0__.object({
    prevPassword: zod__WEBPACK_IMPORTED_MODULE_0__.string().min(8, "পাসওয়ার্ড কমপক্ষে আট অক্ষরের হতে হবে"),
    newPassword: zod__WEBPACK_IMPORTED_MODULE_0__.string().min(8, "নতুন পাসওয়ার্ড কমপক্ষে আট অক্ষরের হতে হবে"),
    confirmPassword: zod__WEBPACK_IMPORTED_MODULE_0__.string()
}).refine((data)=>data.newPassword === data.confirmPassword, {
    message: "অবশ্যই উপরের পাসওয়ার্ডে সাথে মিলতে হবে",
    path: [
        "confirmPassword"
    ]
});
// enroll request in a course
const PaymentSchema = zod__WEBPACK_IMPORTED_MODULE_0__.object({
    paymentMethod: zod__WEBPACK_IMPORTED_MODULE_0__.string().refine((value)=>[
            "Bkash",
            "Nagad",
            "Rocket",
            "Cash"
        ].includes(value), {
        message: "সঠিক পেমেন্ট পদ্ধতি নির্বাচন করুন"
    }),
    transactionId: zod__WEBPACK_IMPORTED_MODULE_0__.string().optional(),
    amount: zod__WEBPACK_IMPORTED_MODULE_0__.string().optional().refine((value)=>!isNaN(value), {
        message: "পেমেন্ট অ্যামাউন্ট সংখ্যা হতে হবে"
    }),
    status: zod__WEBPACK_IMPORTED_MODULE_0__.string().optional(),
    comment: zod__WEBPACK_IMPORTED_MODULE_0__.string().optional()
}).refine((data)=>{
    return data.paymentMethod === "Cash" || !!data.transactionId;
}, {
    path: [
        "transactionId"
    ],
    message: "ট্রানজেকশন আইডি ইনপুট করুন"
}).refine((data)=>{
    return !!data.amount;
}, {
    path: [
        "amount"
    ],
    message: "পেমেন্ট অ্যামাউন্ট ইনপুট করুন"
});
// batch create schema validation
const BatchSchema = zod__WEBPACK_IMPORTED_MODULE_0__.object({
    courseId: zod__WEBPACK_IMPORTED_MODULE_0__.string().min(1, "কোর্স আইডি ইনপুট করুন"),
    code: zod__WEBPACK_IMPORTED_MODULE_0__.string().min(1, "ব্যাচ কোড ইনপুট করুন"),
    days: zod__WEBPACK_IMPORTED_MODULE_0__.array(zod__WEBPACK_IMPORTED_MODULE_0__["enum"]([
        "শনিবার",
        "রবিবার",
        "সোমবার",
        "মঙ্গলবার",
        "বুধবার",
        "বৃহস্পতিবার",
        "শুক্রবার", 
    ])).refine((data)=>{
        return data.length > 0;
    }, {
        message: "কমপক্ষে একটি দিন সিলেক্ট করুন"
    }),
    startDate: zod__WEBPACK_IMPORTED_MODULE_0__.date().nullable(),
    time: zod__WEBPACK_IMPORTED_MODULE_0__.string().refine((data)=>{
        const timeRegex = /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/;
        return timeRegex.test(data);
    }, {
        message: "সঠিক টাইম ফরমেট (HH:mm) ইনপুট করুন"
    }),
    status: zod__WEBPACK_IMPORTED_MODULE_0__.string().optional()
});
// add bacth id to enroll
const BatchEnrollSchema = zod__WEBPACK_IMPORTED_MODULE_0__.object({
    enrollId: zod__WEBPACK_IMPORTED_MODULE_0__.string().min(1, "ইনরোল আইডি ইনপুট করুন")
});
// feedback create validation
const FeedbackSchema = zod__WEBPACK_IMPORTED_MODULE_0__.object({
    star: zod__WEBPACK_IMPORTED_MODULE_0__.string().refine((value)=>[
            "1",
            "2",
            "3",
            "4",
            "5"
        ].includes(value), {
        message: "স্টার 1-5 হতে হবে"
    }),
    comment: zod__WEBPACK_IMPORTED_MODULE_0__.string().min(1, {
        message: "কমেন্ট ইনপুট করুন"
    }),
    status: zod__WEBPACK_IMPORTED_MODULE_0__.string().optional()
});
// seminar create validation
const SeminarSchema = zod__WEBPACK_IMPORTED_MODULE_0__.object({
    title: zod__WEBPACK_IMPORTED_MODULE_0__.string().refine((data)=>data.trim() !== "", {
        message: "সেমিনার টাইটেল ইনপুট করুন"
    }),
    shortDescription: zod__WEBPACK_IMPORTED_MODULE_0__.string().refine((data)=>data.trim() !== "", {
        message: "শর্ট ডেসক্রিপশন ইনপুট করুন"
    }),
    description: zod__WEBPACK_IMPORTED_MODULE_0__.string().refine((data)=>data.trim() !== "", {
        message: "ডেসক্রিপশন ইনপুট করুন"
    }),
    status: zod__WEBPACK_IMPORTED_MODULE_0__.string().optional()
});
// participant create validation
const ParticipantSchema = zod__WEBPACK_IMPORTED_MODULE_0__.object({
    name: zod__WEBPACK_IMPORTED_MODULE_0__.string().refine((data)=>data.trim() !== "", {
        message: "নাম ইনপুট করুন"
    }),
    phone: zod__WEBPACK_IMPORTED_MODULE_0__.string().regex(/^(01[3456789]\d{8})$/, "সঠিক মোবাইল নাম্বার ইনপুট করুন"),
    address: zod__WEBPACK_IMPORTED_MODULE_0__.string().refine((data)=>data.trim() !== "", {
        message: "ঠিকানা ইনপুট করুন"
    }),
    occupation: zod__WEBPACK_IMPORTED_MODULE_0__.string().optional(),
    education: zod__WEBPACK_IMPORTED_MODULE_0__.string().optional(),
    institute: zod__WEBPACK_IMPORTED_MODULE_0__.string().optional()
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;