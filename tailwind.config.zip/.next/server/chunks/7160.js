"use strict";
exports.id = 7160;
exports.ids = [7160];
exports.modules = {

/***/ 7160:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Ax": () => (/* binding */ checkAdmin),
  "IF": () => (/* binding */ checkLoggedin),
  "Xx": () => (/* binding */ checkLogin)
});

// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
// EXTERNAL MODULE: external "mongoose"
var external_mongoose_ = __webpack_require__(1185);
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_);
;// CONCATENATED MODULE: ./src/lib/connect.js

const MONGODB_URL = process.env.MONGODB_URL;
if (!MONGODB_URL) {
    throw new Error("Please define the MONGODB_URL environment variable inside .env.local");
}
let cached = global.mongoose;
if (!cached) {
    cached = global.mongoose = {
        conn: null,
        promise: null
    };
}
async function connectDB() {
    if (cached.conn) {
        return cached.conn;
    }
    if (!cached.promise) {
        const opts = {
            bufferCommands: false
        };
        cached.promise = external_mongoose_default().connect(MONGODB_URL, opts).then((mongoose)=>{
            return mongoose;
        });
    }
    cached.conn = await cached.promise;
    return cached.conn;
}
/* harmony default export */ const connect = (connectDB);

;// CONCATENATED MODULE: ./src/models/userModel.js

const { Schema  } = (external_mongoose_default());
const userSchema = new Schema({
    name: String,
    phone: {
        type: String,
        required: true,
        unique: true
    },
    role: {
        type: String,
        default: "General"
    },
    otp: String,
    otpExpires: Date,
    token: String,
    email: String,
    image: String,
    password: String,
    refer: {
        type: Schema.Types.ObjectId,
        ref: "User",
        default: null
    },
    address: String,
    guardian: String,
    guardianPhone: String,
    education: String,
    institute: String,
    status: {
        type: String,
        required: true,
        enum: [
            "Verified",
            "Unverified"
        ],
        default: "Unverified"
    }
}, {
    timestamps: true
});
const userModel = (external_mongoose_default()).models.User || external_mongoose_default().model("User", userSchema);
/* harmony default export */ const models_userModel = (userModel);

;// CONCATENATED MODULE: ./src/middleware/clientAuth.js



async function checkAdmin(context) {
    const session = await (0,react_.getSession)(context);
    if (session) {
        await connect();
        const user = await models_userModel.findById(session.user._id).select("role");
        if (user.role !== "Admin") {
            return {
                redirect: {
                    destination: `/login`,
                    permanent: false
                }
            };
        }
    } else {
        return {
            redirect: {
                destination: `/login`,
                permanent: false
            }
        };
    }
    return {
        props: {}
    };
}
async function checkLogin(context) {
    const session = await (0,react_.getSession)(context);
    if (!session) {
        return {
            redirect: {
                destination: `/login`,
                permanent: false
            }
        };
    }
    return {
        props: {}
    };
}
async function checkLoggedin(context) {
    const session = await (0,react_.getSession)(context);
    if (session) {
        return {
            redirect: {
                destination: `/profile`,
                permanent: false
            }
        };
    }
    return {
        props: {}
    };
}


/***/ })

};
;