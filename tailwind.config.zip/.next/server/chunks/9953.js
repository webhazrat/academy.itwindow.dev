"use strict";
exports.id = 9953;
exports.ids = [9953];
exports.modules = {

/***/ 9953:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);


const courseSchema = new mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema({
    title: {
        type: String,
        required: true
    },
    slug: {
        type: String,
        required: true,
        unique: true
    },
    excerpt: String,
    description: String,
    topics: [
        {
            _id: false,
            value: String
        }
    ],
    details: [
        {
            _id: false,
            question: String,
            answer: String
        }, 
    ],
    icon: String,
    image: String,
    requirements: [
        {
            _id: false,
            value: String
        }
    ],
    knows: [
        {
            _id: false,
            value: String
        }
    ],
    hows: [
        {
            _id: false,
            value: String
        }
    ],
    fee: String,
    prevFee: String,
    status: {
        type: String,
        default: "Published"
    },
    order: {
        type: Number,
        default: 0
    }
}, {
    timestamps: true
});
const courseModel = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Course) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("Course", courseSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (courseModel);


/***/ })

};
;