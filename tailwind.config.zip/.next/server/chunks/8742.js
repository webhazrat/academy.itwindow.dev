"use strict";
exports.id = 8742;
exports.ids = [8742];
exports.modules = {

/***/ 8742:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ generateOTP),
/* harmony export */   "RA": () => (/* binding */ generateToken),
/* harmony export */   "Vl": () => (/* binding */ unlinkPhoto),
/* harmony export */   "X": () => (/* binding */ sendSMS),
/* harmony export */   "z3": () => (/* binding */ uId),
/* harmony export */   "zy": () => (/* binding */ multerStorage)
/* harmony export */ });
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6113);
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(crypto__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var multer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1738);
/* harmony import */ var multer__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(multer__WEBPACK_IMPORTED_MODULE_3__);




const generateOTP = ()=>{
    return crypto__WEBPACK_IMPORTED_MODULE_2___default().randomInt(1000, 10000).toString();
};
const generateToken = ()=>{
    return crypto__WEBPACK_IMPORTED_MODULE_2___default().randomBytes(16).toString("hex");
};
const uId = ()=>{
    const randdomString = crypto__WEBPACK_IMPORTED_MODULE_2___default().randomBytes(6).toString("hex");
    return `${Date.now()}-${randdomString}`;
};
async function sendSMS(phone, msg) {
    const encodeMsg = encodeURIComponent(msg);
    try {
        const response = await fetch(`https://tpsms.xyz/sms/api?action=send-sms&api_key=${process.env.SMS_API_KEY}=&to=${phone}&from=8809612444246&sms=${encodeMsg}`);
        const data = await response.json();
        return Promise.resolve(data);
    } catch (error) {
        return Promise.reject(error);
    }
}
function multerStorage(dest) {
    const createStorage = ()=>{
        return multer__WEBPACK_IMPORTED_MODULE_3___default().diskStorage({
            destination: function(req, file, cb) {
                const uploadsDir = path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), dest);
                if (!fs__WEBPACK_IMPORTED_MODULE_0___default().existsSync(uploadsDir)) {
                    fs__WEBPACK_IMPORTED_MODULE_0___default().mkdirSync(uploadsDir);
                }
                cb(null, uploadsDir);
            },
            filename: function(req, file, cb) {
                const ext = path__WEBPACK_IMPORTED_MODULE_1___default().extname(file.originalname);
                cb(null, uId() + ext);
            }
        });
    };
    const upload = multer__WEBPACK_IMPORTED_MODULE_3___default()({
        storage: createStorage()
    });
    return Promise.resolve(upload);
}
const unlinkPhoto = (image, dest)=>{
    const currentPhotoPath = image && path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), dest, image);
    if (fs__WEBPACK_IMPORTED_MODULE_0___default().existsSync(currentPhotoPath)) {
        fs__WEBPACK_IMPORTED_MODULE_0___default().unlink(currentPhotoPath, (error)=>{
            return error;
        });
    } else {
        return true;
    }
};


/***/ })

};
;